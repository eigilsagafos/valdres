import { StoreTreeCounterId } from "./committed-store-tree/counter-ids"
import { OrderedMembership } from "./ordered-membership"
import type {
    CollectionIndexHost,
    CollectionIndexRuntime,
    IndexScopeDelta,
} from "./collection-index-protocol"
import type {
    AnyState,
    CollectionCommitPlan,
    CollectionCommitSource,
    CollectionMutationKind,
    ControlFaultSession,
    OptionalCollectionVTable,
    SynchronousResult,
} from "./committed-store-tree/runtime-domain"
import {
    COLLECTION_EFFECTIVE_DELTAS_PREPARED,
    COLLECTION_INDEX_ROUTE_VISITS,
    COLLECTION_EFFECTIVE_INSERT,
    COLLECTION_EFFECTIVE_REMOVE,
    COLLECTION_EFFECTIVE_UPDATE,
    COLLECTION_INTENT_DELETE,
    COLLECTION_INTENT_RESET,
    COLLECTION_INTENT_SET,
    COLLECTION_INTENT_UPDATE,
    COLLECTION_MEMBERSHIP_ARRAY_ALLOCATIONS,
    COLLECTION_MEMBERSHIP_INSERT,
    COLLECTION_MEMBERSHIP_MATERIALIZED,
    COLLECTION_MEMBERSHIP_PUBLISHED,
    COLLECTION_MEMBERSHIP_RECORD_CREATIONS,
    COLLECTION_MEMBERSHIP_REMOVE,
    COLLECTION_MEMBERSHIP_ROUTE_VISITS,
    COLLECTION_MEMBERSHIP_ROWS_SCANNED,
    COLLECTION_MEMBERSHIP_SOURCES_CHANGED,
    COLLECTION_OWNER_RELEASES,
    COLLECTION_OWNER_RETAINS,
    COLLECTION_OWNER_RETENTION_SETS_CREATED,
    COLLECTION_ROW_FINAL_RESOLUTION_VISITS,
    COLLECTION_ROW_INTENT_STORAGE_ALLOCATIONS,
    COLLECTION_ROW_INTENTS_STAGED,
    COLLECTION_ROW_MATERIALIZED,
    COLLECTION_ROW_PUBLISHED,
    COLLECTION_ROW_ROUTE_VISITS,
    COLLECTION_ROW_SOURCES_CHANGED,
} from "./collection-inspection-protocol"
import {
    WeakHandleSet,
    type OutcomeToken,
    type StoreScopeNode,
} from "./committed-store-tree/scope-node"
import { TreeDraft } from "./committed-store-tree/tree-transaction"

type CollectionHandle = object
type CollectionRowHandle = object

type InspectedThenable =
    | Readonly<{ kind: "not-thenable" }>
    | Readonly<{
          kind: "thenable"
          target: object | ((...args: never[]) => unknown)
          then: (...args: unknown[]) => unknown
      }>
    | Readonly<{ kind: "inspection-error"; error: unknown }>

export type CollectionDraftLocal =
    | Readonly<{ kind: "none" }>
    | Readonly<{ kind: "present"; value: unknown }>
    | Readonly<{ kind: "absent" }>

export type CollectionDraftOutcome =
    | Readonly<{ kind: "present"; value: unknown }>
    | Readonly<{ kind: "absent" }>

/** Captures local ownership separately from the effective read. `inherited`
 * is the outcome exposed by Reset. */
export interface CollectionDraftBaseline {
    readonly local: CollectionDraftLocal
    readonly effective: CollectionDraftOutcome
    readonly inherited: CollectionDraftOutcome
}

export interface CollectionKernelBindings {
    lookupRow(row: unknown): CollectionHandle | undefined
    lookupCollection(collection: unknown): boolean
    lookupDiagnosticName(node: object): unknown
    runGuarded<Result>(
        session: ControlFaultSession,
        operation: () => Result,
    ): Result
    inspectThenable(value: unknown): InspectedThenable
    containThenable(
        inspected: Extract<InspectedThenable, { kind: "thenable" }>,
    ): void
}

type CollectionBaselineReader = (
    scope: StoreScopeNode,
    row: CollectionRowHandle,
    collection: CollectionHandle,
) => CollectionDraftBaseline

type FinalRowIntent =
    | Readonly<{ kind: "present"; value: unknown }>
    | Readonly<{ kind: "absent" }>
    | Readonly<{ kind: "reset" }>

type PresenceEventKind = FinalRowIntent["kind"]

type CommittedRowLocal = Exclude<CollectionDraftLocal, { kind: "none" }>

interface RowViewRecord {
    readonly scope: StoreScopeNode
    readonly atom: CollectionRowHandle
    served: Readonly<{ token: OutcomeToken; outcome: SynchronousResult }>
    inheritedFrom: RowViewRecord | undefined
    readonly inheritingChildren: WeakHandleSet<RowViewRecord>
}

interface MembershipRecord {
    ordered?: OrderedMembership | undefined
    /** Set once this scope has changed local row ownership in the collection;
     * cleared when a bulk scope reset rebases the order onto the parent. */
    localHistory?: boolean
    indexedChildren?: WeakHandleSet<MembershipRecord>
    snapshotDirty?: boolean
    readonly scope: StoreScopeNode
    readonly atom: CollectionHandle
    served: Readonly<{ token: OutcomeToken; outcome: SynchronousResult }>
    inheritedFrom: MembershipRecord | undefined
    readonly inheritingChildren: WeakHandleSet<MembershipRecord>
}

interface CollectionScopeSidecar {
    rowLocals: WeakMap<CollectionRowHandle, CommittedRowLocal> | undefined
    ownedRows: Set<CollectionRowHandle> | undefined
    rowViews: WeakMap<CollectionRowHandle, RowViewRecord> | undefined
    liveRowViews: WeakHandleSet<RowViewRecord> | undefined
    memberships: WeakMap<CollectionHandle, MembershipRecord> | undefined
    liveMemberships: WeakHandleSet<MembershipRecord> | undefined
}

interface RowApplyPlan {
    readonly coordinate: DraftCoordinate
    readonly local: CollectionDraftLocal
    readonly ownershipChanged: boolean
}

interface RowSettlementPlan extends CollectionCommitSource {
    readonly record: RowViewRecord
    readonly before: CollectionDraftOutcome
    readonly outcome: CollectionDraftOutcome
}

interface MembershipPlanNode {
    readonly scope: StoreScopeNode
    readonly atom: CollectionHandle
    readonly existing: MembershipRecord | undefined
    readonly parent: MembershipPlanNode | undefined
    readonly beforeRows: readonly CollectionRowHandle[]
    readonly plannedChildren: MembershipPlanNode[]
    finalRows: readonly CollectionRowHandle[] | undefined
    membershipChangedFromBefore: boolean | undefined
    membershipChanges?: Map<CollectionRowHandle, MembershipPresenceTimeline>
    installed: MembershipRecord | undefined
    orderedPatch?: { removals: object[]; births: object[] }
    /** Bulk scope reset: order is rebuilt as an untouched child's would be. */
    rebase?: RebaseMarker
    follower?: boolean
    orderedRebuild?: readonly CollectionRowHandle[]
    affected: boolean
    containsAffected: boolean
}

interface MembershipSettlementPlan extends CollectionCommitSource {
    readonly node: MembershipPlanNode
    readonly record: MembershipRecord
    readonly rows: readonly CollectionRowHandle[]
}

interface ScopedCollectionCommitPlan extends CollectionCommitPlan {
    readonly historyMarks?:
        | readonly Readonly<{
              scope: StoreScopeNode
              collection: CollectionHandle
              history: boolean
          }>[]
        | undefined
    readonly rows: readonly RowApplyPlan[]
    readonly rowSettlements: readonly RowSettlementPlan[]
    readonly membershipInstalls: readonly MembershipPlanNode[]
    readonly membershipSettlements: readonly MembershipSettlementPlan[]
    readonly sources: readonly CollectionCommitSource[]
    readonly indexPlan:
        | { publish(): readonly CollectionCommitSource[] }
        | undefined
    readonly orderedNodes: readonly MembershipPlanNode[] | undefined
}

interface PresenceEvent {
    readonly coordinateId: number
    readonly scope: StoreScopeNode
    readonly row: CollectionRowHandle
    readonly collection: CollectionHandle
    readonly kind: PresenceEventKind
    readonly sequence: number
}

const BASELINE_BIRTH = Symbol("collection baseline birth")
type EnablingBirth = number | typeof BASELINE_BIRTH

interface MembershipPresenceTimeline {
    readonly baselinePresent: boolean
    readonly transitions: readonly Readonly<{
        sequence: number
        present: boolean
    }>[]
    readonly birth: EnablingBirth | undefined
}

/** Inspection-only placements for a restored (bulk-reset) membership: rows it
 * gains are inserts and rows it loses are removals, as `applyCommit` reports
 * them for ordinary membership changes. Pure reordering reports neither. */
const restoredMembershipChanges = (
    before: readonly CollectionRowHandle[],
    after: readonly CollectionRowHandle[],
): Map<CollectionRowHandle, MembershipPresenceTimeline> => {
    const changes = new Map<CollectionRowHandle, MembershipPresenceTimeline>()
    const kept = new Set(after)
    for (const row of before)
        if (!kept.has(row))
            changes.set(row, {
                baselinePresent: true,
                transitions: [],
                birth: undefined,
            })
    const previous = new Set(before)
    for (const row of after)
        if (!previous.has(row))
            changes.set(row, {
                baselinePresent: false,
                transitions: [],
                birth: 0,
            })
    return changes
}

interface DraftCoordinate {
    readonly scope: StoreScopeNode
    readonly row: CollectionRowHandle
    readonly collection: CollectionHandle
    readonly baseline: CollectionDraftBaseline
    readonly discoveryIndex: number
    planIndex: number | undefined
    final: FinalRowIntent | undefined
    finalOperation: CollectionMutationKind | undefined
    enablingBirth: EnablingBirth | undefined
}

interface MembershipMemo {
    readonly revision: number
    readonly rows: readonly CollectionRowHandle[]
}

const isDescendantOf = (
    scope: StoreScopeNode,
    ancestor: StoreScopeNode,
): boolean => {
    for (
        let current = scope.parent;
        current !== undefined;
        current = current.parent
    )
        if (current === ancestor) return true
    return false
}

/** One bulk-reset scope in a draft: events before `start` no longer shape
 * its order; `collections` are those whose order may differ from the parent. */
interface RebaseMarker {
    readonly start: number
    readonly end: number
    readonly collections: Set<CollectionHandle>
}

interface DraftRowLane {
    readonly coordinatesByAncestor: Map<StoreScopeNode, DraftCoordinate[]>
    readonly historyByScope: Map<StoreScopeNode, PresenceEvent[]>
}

interface DraftLane {
    readonly byScope: Map<
        StoreScopeNode,
        Map<CollectionRowHandle, DraftCoordinate>
    >
    readonly planOrder: DraftCoordinate[]
    readonly history: PresenceEvent[]
    readonly historyByCollectionScope: Map<
        CollectionHandle,
        Map<StoreScopeNode, PresenceEvent[]>
    >
    readonly byRow: Map<CollectionRowHandle, DraftRowLane>
    readonly revisionByCollection: Map<CollectionHandle, number>
    queryRevisionByCollection?: Map<CollectionHandle, number>
    readonly membershipMemo: Map<
        StoreScopeNode,
        Map<CollectionHandle, MembershipMemo>
    >
    nextDiscoveryIndex: number
    hasAcceptedIntent: boolean
    rebased?: Map<StoreScopeNode, RebaseMarker>
    /** Every scope explicitly reset in this draft, including resets that
     * restore no collection yet; `rebased` holds those that restore one. */
    cleared?: Map<StoreScopeNode, RebaseMarker>
}

export interface CollectionDraftInspection {
    readonly discoveryOrder: readonly Readonly<{
        id: number
        baselineLocal: CollectionDraftLocal["kind"]
        baselineEffective: CollectionDraftOutcome["kind"]
        baselineInherited: CollectionDraftOutcome["kind"]
        final: FinalRowIntent["kind"] | undefined
        enablingBirth: number | "baseline" | undefined
    }>[]
    readonly planOrder: readonly Readonly<{
        id: number
        baselineLocal: CollectionDraftLocal["kind"]
        baselineEffective: CollectionDraftOutcome["kind"]
        baselineInherited: CollectionDraftOutcome["kind"]
        final: FinalRowIntent["kind"] | undefined
        enablingBirth: number | "baseline" | undefined
    }>[]
    readonly history: readonly Readonly<{
        coordinateId: number
        kind: PresenceEventKind
        sequence: number
    }>[]
    readonly membershipMemoCount: number
    revision(collection: CollectionHandle): number
}

export interface CollectionDraftKernel extends OptionalCollectionVTable {
    installIndexes(
        create: (host: CollectionIndexHost) => CollectionIndexRuntime,
    ): CollectionIndexRuntime
    stageSet(
        draft: TreeDraft,
        scope: StoreScopeNode,
        row: CollectionRowHandle,
        value: unknown,
        session: ControlFaultSession,
    ): void
    stageUpdate(
        draft: TreeDraft,
        scope: StoreScopeNode,
        row: CollectionRowHandle,
        update: unknown,
        session: ControlFaultSession,
    ): void
    stageDelete(
        draft: TreeDraft,
        scope: StoreScopeNode,
        row: CollectionRowHandle,
    ): void
    stageReset(
        draft: TreeDraft,
        scope: StoreScopeNode,
        row: CollectionRowHandle,
    ): void
    readDraftRow(
        draft: TreeDraft,
        scope: StoreScopeNode,
        row: CollectionRowHandle,
    ): unknown
    readDraftCollection(
        draft: TreeDraft,
        scope: StoreScopeNode,
        collection: CollectionHandle,
    ): readonly CollectionRowHandle[]
    beginMembershipRebuildTraceForTest(): () => readonly object[]
    beginMembershipPlacementTraceForTest(): () => Readonly<{
        coordinates: number
        states: number
    }>
    inspectDraft(draft: TreeDraft): CollectionDraftInspection | undefined
}

abstract class ImmutableCollectionError extends Error {
    abstract readonly code: string

    protected seal(): void {
        Object.freeze(this)
    }
}

export class InvalidSynchronousCollectionValueError extends ImmutableCollectionError {
    readonly code = "VALDRES_INVALID_SYNCHRONOUS_COLLECTION_VALUE"

    constructor() {
        super("Collection row values must be synchronous")
        this.name = "InvalidSynchronousCollectionValueError"
        this.seal()
    }
}

export class UndefinedCollectionValueError extends ImmutableCollectionError {
    readonly code = "VALDRES_UNDEFINED_COLLECTION_VALUE"

    constructor() {
        super("Collection row values cannot be undefined")
        this.name = "UndefinedCollectionValueError"
        this.seal()
    }
}

export class MissingCollectionRowError extends ImmutableCollectionError {
    readonly code = "VALDRES_MISSING_COLLECTION_ROW"

    constructor() {
        super("Cannot update an absent collection row")
        this.name = "MissingCollectionRowError"
        this.seal()
    }
}

const NONE: CollectionDraftLocal = Object.freeze({ kind: "none" })
const ABSENT_LOCAL: CollectionDraftLocal = Object.freeze({ kind: "absent" })
const ABSENT: CollectionDraftOutcome = Object.freeze({ kind: "absent" })
const EMPTY_ROWS = Object.freeze([]) as readonly CollectionRowHandle[]
const presentLocal = (value: unknown): CollectionDraftLocal =>
    Object.freeze({ kind: "present", value })

const presentOutcome = (value: unknown): CollectionDraftOutcome =>
    Object.freeze({ kind: "present", value })

const sameOutcome = (
    first: CollectionDraftOutcome,
    second: CollectionDraftOutcome,
): boolean =>
    first.kind === second.kind &&
    (first.kind === "absent" ||
        (second.kind === "present" && Object.is(first.value, second.value)))

const sameLocal = (
    first: CollectionDraftLocal,
    second: CollectionDraftLocal,
): boolean =>
    first.kind === second.kind &&
    (first.kind !== "present" ||
        (second.kind === "present" && Object.is(first.value, second.value)))

const freezeBaseline = (
    baseline: CollectionDraftBaseline,
): CollectionDraftBaseline => {
    const local =
        baseline.local.kind === "present"
            ? presentLocal(baseline.local.value)
            : baseline.local.kind === "absent"
              ? ABSENT_LOCAL
              : NONE
    const effective =
        baseline.effective.kind === "present"
            ? presentOutcome(baseline.effective.value)
            : ABSENT
    const inherited =
        baseline.inherited.kind === "present"
            ? presentOutcome(baseline.inherited.value)
            : ABSENT
    if (local.kind === "none" && !sameOutcome(effective, inherited)) {
        throw new Error(
            "Collection baseline without local ownership must equal inherited outcome",
        )
    }
    if (
        local.kind === "present" &&
        (effective.kind !== "present" ||
            !Object.is(local.value, effective.value))
    ) {
        throw new Error(
            "Collection present local baseline must equal its effective outcome",
        )
    }
    if (local.kind === "absent" && effective.kind !== "absent") {
        throw new Error(
            "Collection absent local baseline must be effectively absent",
        )
    }
    return Object.freeze({ local, effective, inherited })
}

const currentLocal = (coordinate: DraftCoordinate): CollectionDraftLocal => {
    const final = coordinate.final
    if (final === undefined) return coordinate.baseline.local
    if (final.kind === "present") return presentLocal(final.value)
    return final.kind === "absent" ? ABSENT_LOCAL : NONE
}

const outcomeForLocal = (
    local: CollectionDraftLocal,
    inherited: CollectionDraftOutcome,
): CollectionDraftOutcome =>
    local.kind === "present"
        ? presentOutcome(local.value)
        : local.kind === "absent"
          ? ABSENT
          : inherited

const servedOutcome = (outcome: CollectionDraftOutcome): SynchronousResult =>
    Object.freeze({
        kind: "value",
        value: outcome.kind === "present" ? outcome.value : undefined,
    })

/** @internal Tree-shakeable draft and committed-membership engine. The
 * optional baseline reader exists only for deterministic draft tests. */
export const createCollectionKernel = (
    bindings: CollectionKernelBindings,
    readBaselineOverride?: CollectionBaselineReader,
): CollectionDraftKernel => {
    let indexes: CollectionIndexRuntime | undefined
    const lanes = new WeakMap<TreeDraft, DraftLane>()
    const scopeSidecars = new WeakMap<StoreScopeNode, CollectionScopeSidecar>()
    let membershipRebuildTraceForTest: object[] | undefined
    let membershipPlacementTraceForTest:
        | { coordinates: number; states: number }
        | undefined

    const extensionRecorder = (scope: StoreScopeNode) =>
        scope.coordinator?.evaluate?.recordExtension

    const recordCounter = (
        scope: StoreScopeNode,
        code: number,
        amount = 1,
    ): void => {
        extensionRecorder(scope)?.(code, amount)
    }

    const recordDetail = (
        scope: StoreScopeNode,
        code: number,
        target: object,
        related?: object,
    ): void => {
        extensionRecorder(scope)?.(code, scope, target, related)
    }

    const sameRowsWhileProducingSnapshot = (
        scope: StoreScopeNode,
        first: readonly CollectionRowHandle[],
        second: readonly CollectionRowHandle[],
    ): boolean => {
        if (first.length !== second.length) return false
        const recorder = extensionRecorder(scope)
        if (recorder === undefined) {
            for (let index = 0; index < first.length; index++) {
                if (!Object.is(first[index], second[index])) return false
            }
            return true
        }
        for (let index = 0; index < first.length; index++) {
            if (!Object.is(first[index], second[index])) {
                recorder(COLLECTION_MEMBERSHIP_ROWS_SCANNED, index + 1)
                return false
            }
        }
        if (first.length) {
            recorder(COLLECTION_MEMBERSHIP_ROWS_SCANNED, first.length)
        }
        return true
    }

    const sidecarFor = (scope: StoreScopeNode): CollectionScopeSidecar => {
        let sidecar = scopeSidecars.get(scope)
        if (sidecar !== undefined) return sidecar
        sidecar = {
            rowLocals: undefined,
            ownedRows: undefined,
            rowViews: undefined,
            liveRowViews: undefined,
            memberships: undefined,
            liveMemberships: undefined,
        }
        scopeSidecars.set(scope, sidecar)
        return sidecar
    }

    const committedLocal = (
        scope: StoreScopeNode,
        row: CollectionRowHandle,
    ): CollectionDraftLocal =>
        scopeSidecars.get(scope)?.rowLocals?.get(row) ?? NONE

    const committedOutcome = (
        scope: StoreScopeNode | undefined,
        row: CollectionRowHandle,
    ): CollectionDraftOutcome => {
        let current = scope
        while (current !== undefined) {
            const local = committedLocal(current, row)
            if (local.kind === "present") return presentOutcome(local.value)
            if (local.kind === "absent") return ABSENT
            current = current.parent
        }
        return ABSENT
    }

    const readCommittedBaseline: CollectionBaselineReader = (scope, row) => {
        const local = committedLocal(scope, row)
        const inherited = committedOutcome(scope.parent, row)
        return Object.freeze({
            local,
            effective: outcomeForLocal(local, inherited),
            inherited,
        })
    }
    const readBaseline = readBaselineOverride ?? readCommittedBaseline

    const draftLocal = (
        lane: DraftLane,
        scope: StoreScopeNode,
        row: CollectionRowHandle,
        collection: CollectionHandle,
    ): CollectionDraftLocal => {
        const coordinate = lane.byScope.get(scope)?.get(row)
        if (coordinate !== undefined) return currentLocal(coordinate)
        return freezeBaseline(readBaseline(scope, row, collection)).local
    }

    const draftOutcome = (
        lane: DraftLane,
        scope: StoreScopeNode | undefined,
        row: CollectionRowHandle,
        collection: CollectionHandle,
    ): CollectionDraftOutcome => {
        let current = scope
        while (current !== undefined) {
            const local = draftLocal(lane, current, row, collection)
            if (local.kind === "present") return presentOutcome(local.value)
            if (local.kind === "absent") return ABSENT
            if (readBaselineOverride !== undefined) {
                const coordinate = lane.byScope.get(current)?.get(row)
                if (coordinate !== undefined) {
                    return coordinate.baseline.inherited
                }
                return freezeBaseline(readBaseline(current, row, collection))
                    .inherited
            }
            current = current.parent
        }
        return ABSENT
    }

    const replayEnablingBirth = (
        lane: DraftLane,
        scope: StoreScopeNode,
        row: CollectionRowHandle,
        collection: CollectionHandle,
    ): EnablingBirth | undefined => {
        if (readBaselineOverride !== undefined) {
            const baseline = freezeBaseline(
                readBaseline(scope, row, collection),
            )
            let present = baseline.effective.kind === "present"
            let birth: EnablingBirth | undefined = present
                ? BASELINE_BIRTH
                : undefined
            for (const event of lane.byRow
                .get(row)
                ?.historyByScope.get(scope) ?? []) {
                if (
                    !Object.is(event.row, row) ||
                    !Object.is(event.scope, scope)
                ) {
                    continue
                }
                const nextPresent =
                    event.kind === "present" ||
                    (event.kind === "reset" &&
                        baseline.inherited.kind === "present")
                if (!present && nextPresent) birth = event.sequence
                else if (!nextPresent) birth = undefined
                present = nextPresent
            }
            return birth
        }

        return replayRouteBirth(lane, scope, row, collection, undefined)
    }

    const createRowView = (
        scope: StoreScopeNode,
        row: CollectionRowHandle,
        outcome: CollectionDraftOutcome,
        inheritedFrom?: RowViewRecord,
    ): RowViewRecord => {
        const sidecar = sidecarFor(scope)
        const existing = sidecar.rowViews?.get(row)
        if (existing !== undefined) return existing
        const record: RowViewRecord = {
            scope,
            atom: row,
            served: Object.freeze({
                token: scope.createOutcomeToken(),
                outcome: servedOutcome(outcome),
            }),
            inheritedFrom,
            inheritingChildren: new WeakHandleSet(() =>
                scope.coordinator.recordCounter(
                    StoreTreeCounterId.deadRouteCompactions,
                ),
            ),
        }
        let rowViews = sidecar.rowViews
        if (rowViews === undefined) {
            rowViews = new WeakMap()
            sidecar.rowViews = rowViews
        }
        let liveRowViews = sidecar.liveRowViews
        if (liveRowViews === undefined) {
            liveRowViews = new WeakHandleSet(() =>
                scope.coordinator.recordCounter(
                    StoreTreeCounterId.deadRouteCompactions,
                ),
            )
            sidecar.liveRowViews = liveRowViews
        }
        rowViews.set(row, record)
        liveRowViews.add(record)
        recordDetail(
            scope,
            COLLECTION_ROW_MATERIALIZED,
            row,
            bindings.lookupRow(row),
        )
        if (inheritedFrom !== undefined) {
            inheritedFrom.inheritingChildren.add(record)
            scope.coordinator.recordCounter(StoreTreeCounterId.routeAdds)
        }
        return record
    }

    const materializeRowView = (
        scope: StoreScopeNode,
        row: CollectionRowHandle,
    ): RowViewRecord => {
        let currentScope = scope
        const unresolved: StoreScopeNode[] = []
        let current: RowViewRecord
        while (true) {
            recordCounter(currentScope, COLLECTION_ROW_ROUTE_VISITS)
            const sidecar = scopeSidecars.get(currentScope)
            const materialized = sidecar?.rowViews?.get(row)
            if (materialized !== undefined) {
                current = materialized
                break
            }
            const local = sidecar?.rowLocals?.get(row)
            if (local !== undefined) {
                current = createRowView(
                    currentScope,
                    row,
                    local.kind === "present"
                        ? presentOutcome(local.value)
                        : ABSENT,
                )
                break
            }
            if (currentScope.parent === undefined) {
                current = createRowView(currentScope, row, ABSENT)
                break
            }
            unresolved.push(currentScope)
            currentScope = currentScope.parent
        }
        for (let index = unresolved.length - 1; index >= 0; index--) {
            current = createRowView(
                unresolved[index] as StoreScopeNode,
                row,
                current.served.outcome.kind === "value" &&
                    current.served.outcome.value !== undefined
                    ? presentOutcome(current.served.outcome.value)
                    : ABSENT,
                current,
            )
        }
        return current
    }

    const detachRowView = (record: RowViewRecord): void => {
        const inheritedFrom = record.inheritedFrom
        if (inheritedFrom === undefined) return
        inheritedFrom.inheritingChildren.delete(record)
        record.inheritedFrom = undefined
        record.scope.coordinator.recordCounter(StoreTreeCounterId.routeRemoves)
    }

    const attachRowView = (
        record: RowViewRecord,
        inheritedFrom: RowViewRecord,
    ): void => {
        if (Object.is(record.inheritedFrom, inheritedFrom)) return
        detachRowView(record)
        record.inheritedFrom = inheritedFrom
        inheritedFrom.inheritingChildren.add(record)
        record.scope.coordinator.recordCounter(StoreTreeCounterId.routeAdds)
    }

    const membershipRows = (
        record: MembershipRecord,
    ): readonly CollectionRowHandle[] => {
        if (record.snapshotDirty) {
            const rows = Object.freeze([...record.ordered!.entries.keys()])
            recordCounter(
                record.scope,
                COLLECTION_MEMBERSHIP_ROWS_SCANNED,
                rows.length,
            )
            recordCounter(record.scope, COLLECTION_MEMBERSHIP_ARRAY_ALLOCATIONS)
            record.served = servedMembership(
                record.scope,
                rows,
                record.served.token,
            )
            record.snapshotDirty = false
        }
        return record.served.outcome.kind === "value"
            ? (record.served.outcome.value as readonly CollectionRowHandle[])
            : EMPTY_ROWS
    }

    const indexedMembership = (
        scope: StoreScopeNode,
        collection: object,
    ): OrderedMembership => {
        const record = materializeMembership(scope, collection)
        let current: MembershipRecord | undefined = record
        while (current !== undefined && current.ordered === undefined) {
            current.ordered = new OrderedMembership(membershipRows(current))
            const parent: MembershipRecord | undefined = current.inheritedFrom
            if (parent !== undefined) {
                ;(parent.indexedChildren ??= new WeakHandleSet()).add(current)
            }
            current = parent
        }
        return record.ordered!
    }

    const copyMembershipRows = (
        scope: StoreScopeNode,
        rows: readonly CollectionRowHandle[],
    ): readonly CollectionRowHandle[] => {
        if (rows.length) {
            recordCounter(
                scope,
                COLLECTION_MEMBERSHIP_ROWS_SCANNED,
                rows.length,
            )
        }
        const copy = Object.freeze([...rows])
        recordCounter(scope, COLLECTION_MEMBERSHIP_ARRAY_ALLOCATIONS)
        return copy
    }

    const servedMembership = (
        scope: StoreScopeNode,
        rows: readonly CollectionRowHandle[],
        token: OutcomeToken = scope.createOutcomeToken(),
    ): MembershipRecord["served"] =>
        Object.freeze({
            token,
            outcome: Object.freeze({ kind: "value", value: rows }),
        })

    const registerMembershipRecord = (
        scope: StoreScopeNode,
        collection: CollectionHandle,
        rows: readonly CollectionRowHandle[],
        deferred = false,
    ): MembershipRecord => {
        const sidecar = sidecarFor(scope)
        const current = sidecar.memberships?.get(collection)
        if (current !== undefined) return current
        const record: MembershipRecord = {
            scope,
            atom: collection,
            served: servedMembership(
                scope,
                rows,
                // A deferred record must retain its own historical rows even
                // if its parent publishes again before the first child read.
                // EMPTY_ROWS cannot collide with a scope-created token.
                deferred ? (EMPTY_ROWS as unknown as OutcomeToken) : undefined,
            ),
            inheritedFrom: undefined,
            inheritingChildren: new WeakHandleSet(() =>
                scope.coordinator.recordCounter(
                    StoreTreeCounterId.deadRouteCompactions,
                ),
            ),
        }
        let memberships = sidecar.memberships
        if (memberships === undefined) {
            memberships = new WeakMap()
            sidecar.memberships = memberships
        }
        let liveMemberships = sidecar.liveMemberships
        if (liveMemberships === undefined) {
            liveMemberships = new WeakHandleSet(() =>
                scope.coordinator.recordCounter(
                    StoreTreeCounterId.deadRouteCompactions,
                ),
            )
            sidecar.liveMemberships = liveMemberships
        }
        memberships.set(collection, record)
        liveMemberships.add(record)
        recordCounter(scope, COLLECTION_MEMBERSHIP_RECORD_CREATIONS)
        recordDetail(scope, COLLECTION_MEMBERSHIP_MATERIALIZED, collection)
        return record
    }

    const detachMembership = (record: MembershipRecord): void => {
        const inheritedFrom = record.inheritedFrom
        if (inheritedFrom === undefined) return
        inheritedFrom.inheritingChildren.delete(record)
        inheritedFrom.indexedChildren?.delete(record)
        record.inheritedFrom = undefined
        record.scope.coordinator.recordCounter(StoreTreeCounterId.routeRemoves)
    }

    const attachMembership = (
        record: MembershipRecord,
        inheritedFrom: MembershipRecord,
    ): void => {
        if (Object.is(record.inheritedFrom, inheritedFrom)) return
        detachMembership(record)
        record.inheritedFrom = inheritedFrom
        inheritedFrom.inheritingChildren.add(record)
        record.scope.coordinator.recordCounter(StoreTreeCounterId.routeAdds)
    }

    const materializeMembership = (
        scope: StoreScopeNode,
        collection: CollectionHandle,
    ): MembershipRecord => {
        let currentScope = scope
        const unresolved: StoreScopeNode[] = []
        let current: MembershipRecord
        while (true) {
            recordCounter(currentScope, COLLECTION_MEMBERSHIP_ROUTE_VISITS)
            const materialized = scopeSidecars
                .get(currentScope)
                ?.memberships?.get(collection)
            if (materialized !== undefined) {
                current = materialized
                if (
                    current.served.token ===
                    (EMPTY_ROWS as unknown as OutcomeToken)
                ) {
                    const rows = copyMembershipRows(
                        currentScope,
                        membershipRows(current),
                    )
                    current.served = servedMembership(currentScope, rows)
                }
                break
            }
            if (currentScope.parent === undefined) {
                current = registerMembershipRecord(
                    currentScope,
                    collection,
                    copyMembershipRows(currentScope, EMPTY_ROWS),
                )
                break
            }
            unresolved.push(currentScope)
            currentScope = currentScope.parent
        }
        for (let index = unresolved.length - 1; index >= 0; index--) {
            const scope = unresolved[index] as StoreScopeNode
            const rows = copyMembershipRows(scope, membershipRows(current))
            const child = registerMembershipRecord(scope, collection, rows)
            attachMembership(child, current)
            current = child
        }
        return current
    }

    const releaseDraft = (draftValue: object): void => {
        const draft = draftValue as TreeDraft
        indexes?.release(draft)
        const lane = lanes.get(draft)
        if (lane === undefined) return
        lanes.delete(draft)
        for (const coordinates of lane.byScope.values()) {
            for (const coordinate of coordinates.values()) {
                coordinate.final = undefined
                coordinate.finalOperation = undefined
            }
            coordinates.clear()
        }
        lane.byScope.clear()
        lane.planOrder.length = 0
        lane.history.length = 0
        for (const byScope of lane.historyByCollectionScope.values()) {
            for (const history of byScope.values()) history.length = 0
            byScope.clear()
        }
        lane.historyByCollectionScope.clear()
        for (const rowLane of lane.byRow.values()) {
            for (const coordinates of rowLane.coordinatesByAncestor.values()) {
                coordinates.length = 0
            }
            rowLane.coordinatesByAncestor.clear()
            for (const history of rowLane.historyByScope.values()) {
                history.length = 0
            }
            rowLane.historyByScope.clear()
        }
        lane.byRow.clear()
        lane.revisionByCollection.clear()
        lane.queryRevisionByCollection?.clear()
        for (const byCollection of lane.membershipMemo.values()) {
            byCollection.clear()
        }
        lane.membershipMemo.clear()
    }

    const laneFor = (draft: TreeDraft): DraftLane => {
        let lane = lanes.get(draft)
        if (lane !== undefined) return lane
        lane = {
            byScope: new Map(),
            planOrder: [],
            history: [],
            historyByCollectionScope: new Map(),
            byRow: new Map(),
            revisionByCollection: new Map(),
            membershipMemo: new Map(),
            nextDiscoveryIndex: 0,
            hasAcceptedIntent: false,
        }
        draft.installRows(releaseDraft)
        lanes.set(draft, lane)
        return lane
    }

    const collectionForRow = (row: unknown): CollectionHandle => {
        const collection = bindings.lookupRow(row)
        if (collection === undefined) {
            throw new TypeError(
                "Collection draft operation requires a valid row",
            )
        }
        return collection
    }

    const advanceMembershipRevision = (
        lane: DraftLane,
        collection: CollectionHandle,
    ): void => {
        lane.revisionByCollection.set(
            collection,
            (lane.revisionByCollection.get(collection) ?? 0) + 1,
        )
    }

    /** Invalidates every draft read derived from a collection's membership:
     * scope membership memos and memoized draft query results. */
    const invalidateCollectionReads = (
        lane: DraftLane,
        collection: CollectionHandle,
    ): void => {
        advanceMembershipRevision(lane, collection)
        const queryRevision = lane.queryRevisionByCollection?.get(collection)
        if (queryRevision !== undefined)
            lane.queryRevisionByCollection!.set(collection, queryRevision + 1)
    }

    /** True while a bulk scope reset in this draft restores `collection`. */
    const restoringCollection = (
        lane: DraftLane,
        collection: CollectionHandle,
    ): boolean => {
        for (const marker of lane.rebased?.values() ?? [])
            if (marker.collections.has(collection)) return true
        return false
    }

    const coordinateFor = (
        draft: TreeDraft,
        scope: StoreScopeNode,
        row: CollectionRowHandle,
        collection = collectionForRow(row),
    ): DraftCoordinate => {
        const lane = laneFor(draft)
        let coordinates = lane.byScope.get(scope)
        if (coordinates === undefined) {
            coordinates = new Map()
            lane.byScope.set(scope, coordinates)
        }
        let coordinate = coordinates.get(row)
        if (coordinate !== undefined) return coordinate
        if (membershipPlacementTraceForTest !== undefined) {
            membershipPlacementTraceForTest.coordinates++
        }
        const committed = freezeBaseline(readBaseline(scope, row, collection))
        const inherited =
            readBaselineOverride === undefined
                ? draftOutcome(lane, scope.parent, row, collection)
                : committed.inherited
        const baseline = freezeBaseline({
            local: committed.local,
            effective: outcomeForLocal(committed.local, inherited),
            inherited,
        })
        coordinate = {
            scope,
            row,
            collection,
            baseline,
            discoveryIndex: lane.nextDiscoveryIndex++,
            planIndex: undefined,
            final: undefined,
            finalOperation: undefined,
            enablingBirth: undefined,
        }
        coordinates.set(row, coordinate)
        let rowLane = lane.byRow.get(row)
        if (rowLane === undefined) {
            rowLane = {
                coordinatesByAncestor: new Map(),
                historyByScope: new Map(),
            }
            lane.byRow.set(row, rowLane)
        }
        let ancestor: StoreScopeNode | undefined = scope
        while (ancestor !== undefined) {
            let descendants = rowLane.coordinatesByAncestor.get(ancestor)
            if (descendants === undefined) {
                descendants = []
                rowLane.coordinatesByAncestor.set(ancestor, descendants)
            }
            descendants.push(coordinate)
            ancestor = ancestor.parent
        }
        coordinate.enablingBirth = replayEnablingBirth(
            lane,
            scope,
            row,
            collection,
        )
        return coordinate
    }

    const installEvent = (
        draft: TreeDraft,
        coordinate: DraftCoordinate,
        operation: CollectionMutationKind,
        final: FinalRowIntent,
        local: CollectionDraftLocal,
        effective: CollectionDraftOutcome,
    ): void => {
        const beforeLocal = currentLocal(coordinate)
        const lane = laneFor(draft)
        const beforeEffective = draftOutcome(
            lane,
            coordinate.scope,
            coordinate.row,
            coordinate.collection,
        )
        if (
            sameLocal(beforeLocal, local) &&
            sameOutcome(beforeEffective, effective)
        ) {
            return
        }
        // This counter names the draft's first accepted intent storage, not
        // read-only lane, coordinate, or membership-memo allocation.
        if (!lane.hasAcceptedIntent) {
            lane.hasAcceptedIntent = true
            recordCounter(
                coordinate.scope,
                COLLECTION_ROW_INTENT_STORAGE_ALLOCATIONS,
            )
        }
        recordCounter(coordinate.scope, COLLECTION_ROW_INTENTS_STAGED)
        const affectedCoordinates: {
            coordinate: DraftCoordinate
            effective: CollectionDraftOutcome
            placement: EnablingBirth | undefined
        }[] = []
        for (const candidate of lane.byRow
            .get(coordinate.row)!
            .coordinatesByAncestor.get(coordinate.scope) ?? []) {
            const candidateEffective = draftOutcome(
                lane,
                candidate.scope,
                candidate.row,
                candidate.collection,
            )
            affectedCoordinates.push({
                coordinate: candidate,
                effective: candidateEffective,
                placement:
                    candidateEffective.kind === "present"
                        ? candidate.enablingBirth
                        : undefined,
            })
        }

        const sequence = draft.generation
        if (coordinate.planIndex === undefined) {
            coordinate.planIndex = lane.planOrder.length
            lane.planOrder.push(coordinate)
        }
        coordinate.final = final
        coordinate.finalOperation = operation
        const event = Object.freeze({
            coordinateId: coordinate.discoveryIndex,
            scope: coordinate.scope,
            row: coordinate.row,
            collection: coordinate.collection,
            kind: final.kind,
            sequence,
        })
        lane.history.push(event)
        const rowLane = lane.byRow.get(coordinate.row)!
        let scopeHistory = rowLane.historyByScope.get(coordinate.scope)
        if (scopeHistory === undefined) {
            scopeHistory = []
            rowLane.historyByScope.set(coordinate.scope, scopeHistory)
        }
        scopeHistory.push(event)
        let byCollection = lane.historyByCollectionScope.get(
            coordinate.collection,
        )
        if (byCollection === undefined) {
            byCollection = new Map()
            lane.historyByCollectionScope.set(
                coordinate.collection,
                byCollection,
            )
        }
        let collectionScopeHistory = byCollection.get(coordinate.scope)
        if (collectionScopeHistory === undefined) {
            collectionScopeHistory = []
            byCollection.set(coordinate.scope, collectionScopeHistory)
        }
        // The scope's first staged event in this collection ends any mirroring
        // of a restored ancestor (the follower rule requires no staged history).
        const firstScopeEvent = collectionScopeHistory.length === 0
        collectionScopeHistory.push(event)
        let placementChanged = false
        for (const before of affectedCoordinates) {
            const candidate = before.coordinate
            const after = draftOutcome(
                lane,
                candidate.scope,
                candidate.row,
                candidate.collection,
            )
            if (
                before.effective.kind === "absent" &&
                after.kind === "present"
            ) {
                candidate.enablingBirth = sequence
            } else if (after.kind === "absent") {
                candidate.enablingBirth = undefined
            }
            const placement =
                after.kind === "present" ? candidate.enablingBirth : undefined
            if (!Object.is(before.placement, placement)) {
                placementChanged = true
            }
        }
        if (
            placementChanged ||
            (firstScopeEvent &&
                lane.rebased !== undefined &&
                restoringCollection(lane, coordinate.collection) &&
                rebaseFor(lane, coordinate.scope, coordinate.collection) ===
                    undefined)
        ) {
            advanceMembershipRevision(lane, coordinate.collection)
        }
        // Query results depend on row values as well as membership. Advance only
        // queried collections, including ownership changes that affect descendants.
        const queryRevision = lane.queryRevisionByCollection?.get(
            coordinate.collection,
        )
        if (queryRevision !== undefined)
            lane.queryRevisionByCollection!.set(
                coordinate.collection,
                queryRevision + 1,
            )
        draft.markRow(sequence)
    }

    const invalidSynchronousValue =
        (): InvalidSynchronousCollectionValueError =>
            new InvalidSynchronousCollectionValueError()

    const validateValue = (value: unknown): unknown => {
        const inspected = bindings.inspectThenable(value)
        if (inspected.kind === "inspection-error") throw inspected.error
        if (inspected.kind === "thenable") {
            bindings.containThenable(inspected)
            throw invalidSynchronousValue()
        }
        if (value === undefined) throw new UndefinedCollectionValueError()
        return value
    }

    const runUpdater = (
        update: (current: unknown) => unknown,
        current: unknown,
        session: ControlFaultSession,
    ): unknown =>
        bindings.runGuarded(session, () => {
            let candidate: unknown
            try {
                candidate = Reflect.apply(update, undefined, [current])
            } catch (thrown) {
                const inspected = bindings.inspectThenable(thrown)
                if (inspected.kind === "not-thenable") throw thrown
                if (inspected.kind === "inspection-error") {
                    throw inspected.error
                }
                bindings.containThenable(inspected)
                throw invalidSynchronousValue()
            }
            return validateValue(candidate)
        })

    const stageSet: CollectionDraftKernel["stageSet"] = (
        draft,
        scope,
        row,
        value,
        session,
    ) => {
        const collection = collectionForRow(row)
        const admitted = bindings.runGuarded(session, () =>
            validateValue(value),
        )
        const coordinate = coordinateFor(draft, scope, row, collection)
        installEvent(
            draft,
            coordinate,
            "set",
            Object.freeze({ kind: "present", value: admitted }),
            presentLocal(admitted),
            presentOutcome(admitted),
        )
    }

    const stageUpdate: CollectionDraftKernel["stageUpdate"] = (
        draft,
        scope,
        row,
        update,
        session,
    ) => {
        const collection = collectionForRow(row)
        if (typeof update !== "function") {
            throw new TypeError("Collection row update requires an updater")
        }
        const coordinate = coordinateFor(draft, scope, row, collection)
        const current = draftOutcome(laneFor(draft), scope, row, collection)
        if (current.kind === "absent") throw new MissingCollectionRowError()
        const admitted = runUpdater(
            update as (current: unknown) => unknown,
            current.value,
            session,
        )
        installEvent(
            draft,
            coordinate,
            "update",
            Object.freeze({ kind: "present", value: admitted }),
            presentLocal(admitted),
            presentOutcome(admitted),
        )
    }

    const stageDelete: CollectionDraftKernel["stageDelete"] = (
        draft,
        scope,
        row,
    ) => {
        const coordinate = coordinateFor(draft, scope, row)
        installEvent(
            draft,
            coordinate,
            "delete",
            Object.freeze({ kind: "absent" }),
            ABSENT_LOCAL,
            ABSENT,
        )
    }

    const stageReset: CollectionDraftKernel["stageReset"] = (
        draft,
        scope,
        row,
    ) => {
        const coordinate = coordinateFor(draft, scope, row)
        const inherited =
            readBaselineOverride === undefined
                ? draftOutcome(
                      laneFor(draft),
                      scope.parent,
                      row,
                      coordinate.collection,
                  )
                : coordinate.baseline.inherited
        installEvent(
            draft,
            coordinate,
            "reset",
            Object.freeze({ kind: "reset" }),
            NONE,
            inherited,
        )
    }

    const resetAllRows = (draft: TreeDraft, scope: StoreScopeNode): void => {
        const start = draft.generation
        const candidates: CollectionRowHandle[] = []
        const committed = scopeSidecars.get(scope)?.ownedRows
        if (committed !== undefined)
            for (const row of committed) candidates.push(row)
        // Then rows this draft staged in the scope, in first-staging order
        // (coordinates created only by reads carry no plan index).
        const staged = lanes.get(draft)?.byScope.get(scope)
        if (staged !== undefined) {
            const planned: DraftCoordinate[] = []
            for (const coordinate of staged.values()) {
                if (coordinate.planIndex !== undefined) planned.push(coordinate)
            }
            planned.sort((a, b) => a.planIndex! - b.planIndex!)
            for (const coordinate of planned) candidates.push(coordinate.row)
        }
        const visited = new Set<CollectionRowHandle>()
        const owned: CollectionRowHandle[] = []
        for (const row of candidates) {
            if (visited.has(row)) continue
            visited.add(row)
            const coordinate = staged?.get(row)
            if (coordinate !== undefined) {
                if (currentLocal(coordinate).kind === "none") continue
            } else if (committed?.has(row) !== true) continue
            owned.push(row)
        }
        // Rows the reset reveals are births in descendants that keep their own
        // order history; stage them in the parent's current order so that
        // order is defined rather than an ownership-acquisition artifact.
        // Staging order is observable only in descendants with their own
        // history, so scopes without children skip the parent walk.
        if (owned.length > 1 && !scope.children.isEmpty()) {
            const pending = new Set(owned)
            const ordered: CollectionRowHandle[] = []
            for (const collection of new Set(owned.map(collectionForRow)))
                for (const row of readDraftCollection(
                    draft,
                    scope.parent!,
                    collection,
                ))
                    if (pending.delete(row)) ordered.push(row)
            for (const row of owned) if (pending.has(row)) ordered.push(row)
            owned.length = 0
            owned.push(...ordered)
        }
        for (const row of owned) stageReset(draft, scope, row)
        // Order restoration: every collection this scope owned rows in, staged
        // rows in, or ever diverged in is rebased onto its parent's order.
        const collections = new Set<CollectionHandle>()
        for (const row of visited) collections.add(collectionForRow(row))
        scopeSidecars.get(scope)?.liveMemberships?.forEach(record => {
            if (record.localHistory) collections.add(record.atom)
        })
        const lane = laneFor(draft)
        // An explicit reset also restores every collection an ancestor restores
        // in this draft, owned rows or not: the scope must read, and order its
        // later writes, as an untouched child of the restored parent rather
        // than as a descendant keeping its own history. Elsewhere a scope that
        // never diverged already orders as an untouched child.
        for (
            let ancestor = scope.parent;
            ancestor !== undefined;
            ancestor = ancestor.parent
        )
            for (const collection of lane.rebased?.get(ancestor)?.collections ??
                [])
                collections.add(collection)
        const previous = lane.cleared?.get(scope)
        if (previous !== undefined)
            for (const collection of previous.collections)
                collections.add(collection)
        const marker: RebaseMarker = {
            start,
            end: draft.generation,
            collections,
        }
        ;(lane.cleared ??= new Map()).set(scope, marker)
        if (collections.size === 0) return
        ;(lane.rebased ??= new Map()).set(scope, marker)
        // Descendants reset earlier in this draft restore these collections
        // too, whatever order the resets ran in.
        for (const [descendant, cleared] of lane.cleared) {
            if (descendant === scope || !isDescendantOf(descendant, scope))
                continue
            for (const collection of collections)
                cleared.collections.add(collection)
            lane.rebased.set(descendant, cleared)
        }
        for (const collection of collections)
            invalidateCollectionReads(lane, collection)
        draft.markRow(draft.generation)
    }

    /** A descendant keeps mirroring a restored ancestor only if it mirrored
     * that parent before this transaction, staged nothing of its own in the
     * collection, and none of its local rows changes membership against the
     * parent's new rows. Otherwise it keeps its own order history. */
    const mirrorsParent = (
        lane: DraftLane,
        scope: StoreScopeNode,
        collection: CollectionHandle,
        scopeBefore: readonly CollectionRowHandle[],
        parentBefore: readonly CollectionRowHandle[],
        parentAfter: () => readonly CollectionRowHandle[],
    ): boolean => {
        if (lane.historyByCollectionScope.get(collection)?.get(scope)?.length)
            return false
        if (scopeBefore.length !== parentBefore.length) return false
        for (let index = 0; index < scopeBefore.length; index++)
            if (scopeBefore[index] !== parentBefore[index]) return false
        let present: Set<CollectionRowHandle> | undefined
        for (const row of scopeSidecars.get(scope)?.ownedRows ?? []) {
            if (bindings.lookupRow(row) !== collection) continue
            present ??= new Set(parentAfter())
            if (
                (committedLocal(scope, row).kind === "present") !==
                present.has(row)
            )
                return false
        }
        return true
    }

    const rebaseFor = (
        lane: DraftLane,
        scope: StoreScopeNode,
        collection: CollectionHandle,
    ): RebaseMarker | undefined => {
        const marker = lane.rebased?.get(scope)
        return marker?.collections.has(collection) ? marker : undefined
    }

    const hasRestoredAncestor = (
        lane: DraftLane,
        scope: StoreScopeNode,
        collection: CollectionHandle,
    ): boolean => {
        for (
            let ancestor = scope.parent;
            ancestor !== undefined;
            ancestor = ancestor.parent
        )
            if (rebaseFor(lane, ancestor, collection) !== undefined) return true
        return false
    }

    /** Draft-read form of the mirror rule below a rebased (or following) scope. */
    const followsRebase = (
        draft: TreeDraft,
        lane: DraftLane,
        scope: StoreScopeNode,
        collection: CollectionHandle,
    ): boolean => {
        if (rebaseFor(lane, scope, collection) !== undefined) return false
        const parent = scope.parent
        if (parent === undefined) return false
        if (
            rebaseFor(lane, parent, collection) === undefined &&
            !followsRebase(draft, lane, parent, collection)
        )
            return false
        return mirrorsParent(
            lane,
            scope,
            collection,
            membershipRows(materializeMembership(scope, collection)),
            membershipRows(materializeMembership(parent, collection)),
            () => readDraftCollection(draft, parent, collection),
        )
    }

    /** Birth replay along the scope route. With a `chainTop`, every scope
     * reset by a bulk scope reset BELOW that scope starts with no local state
     * and ignores its events before the reset (an untouched-equivalent view);
     * `chainTop` and its ancestors keep their actual history. */
    const replayRouteBirth = (
        lane: DraftLane,
        scope: StoreScopeNode,
        row: CollectionRowHandle,
        collection: CollectionHandle,
        chainTop: StoreScopeNode | undefined,
    ): EnablingBirth | undefined => {
        const route: StoreScopeNode[] = []
        const restored = new Set<StoreScopeNode>()
        const local = new Map<StoreScopeNode, CollectionDraftLocal["kind"]>()
        let current: StoreScopeNode | undefined = scope
        let inChain = chainTop !== undefined
        while (current !== undefined) {
            if (current === chainTop) inChain = false
            route.push(current)
            if (inChain && rebaseFor(lane, current, collection) !== undefined)
                restored.add(current)
            local.set(
                current,
                restored.has(current)
                    ? "none"
                    : freezeBaseline(readBaseline(current, row, collection))
                          .local.kind,
            )
            current = current.parent
        }
        const events: PresenceEvent[] = []
        const rowLane = lane.byRow.get(row)
        if (rowLane !== undefined) {
            for (const routeScope of route) {
                const marker = restored.has(routeScope)
                    ? rebaseFor(lane, routeScope, collection)
                    : undefined
                for (const event of rowLane.historyByScope.get(routeScope) ??
                    [])
                    if (marker === undefined || event.sequence >= marker.start)
                        events.push(event)
            }
            events.sort((first, second) => first.sequence - second.sequence)
        }
        const isPresent = (): boolean => {
            for (const routeScope of route) {
                const kind = local.get(routeScope)
                if (kind === "present") return true
                if (kind === "absent") return false
            }
            return false
        }
        let present = isPresent()
        let birth: EnablingBirth | undefined = present
            ? BASELINE_BIRTH
            : undefined
        for (const event of events) {
            local.set(
                event.scope,
                event.kind === "present"
                    ? "present"
                    : event.kind === "absent"
                      ? "absent"
                      : "none",
            )
            const nextPresent = isPresent()
            if (!present && nextPresent) birth = event.sequence
            else if (!nextPresent) birth = undefined
            present = nextPresent
        }
        return birth
    }

    /** Untouched-child order: `base` (the committed order of `chainTop`, the
     * nearest scope whose order is not restore-derived) filtered to
     * continuously present rows, then births in sequence order. */
    const rebasedRows = (
        lane: DraftLane,
        scope: StoreScopeNode,
        collection: CollectionHandle,
        base: readonly CollectionRowHandle[],
        chainTop: StoreScopeNode,
    ): CollectionRowHandle[] => {
        const history = lane.historyByCollectionScope.get(collection)
        const births = new Map<CollectionRowHandle, EnablingBirth | undefined>()
        let routeScope: StoreScopeNode | undefined = scope
        while (routeScope !== undefined) {
            for (const event of history?.get(routeScope) ?? [])
                if (!births.has(event.row))
                    births.set(
                        event.row,
                        replayRouteBirth(
                            lane,
                            scope,
                            event.row,
                            collection,
                            chainTop,
                        ),
                    )
            routeScope = routeScope.parent
        }
        const next: CollectionRowHandle[] = []
        for (const row of base) {
            if (!births.has(row) || births.get(row) === BASELINE_BIRTH)
                next.push(row)
        }
        const born: { row: CollectionRowHandle; birth: number }[] = []
        for (const [row, birth] of births)
            if (typeof birth === "number") born.push({ row, birth })
        born.sort((first, second) => first.birth - second.birth)
        for (const { row } of born) next.push(row)
        return next
    }

    /** Draft-read restore chain: climb past every rebased or following
     * ancestor. The first other scope's committed order is the base. */
    const restoreChainTop = (
        draft: TreeDraft,
        lane: DraftLane,
        scope: StoreScopeNode,
        collection: CollectionHandle,
    ): StoreScopeNode => {
        let top = scope.parent!
        while (
            rebaseFor(lane, top, collection) !== undefined ||
            followsRebase(draft, lane, top, collection)
        )
            top = top.parent!
        return top
    }

    const readDraftRow: CollectionDraftKernel["readDraftRow"] = (
        draft,
        scope,
        row,
    ) => {
        const coordinate = coordinateFor(draft, scope, row)
        const outcome = draftOutcome(
            laneFor(draft),
            scope,
            row,
            coordinate.collection,
        )
        return outcome.kind === "present" ? outcome.value : undefined
    }

    const readDraftCollection: CollectionDraftKernel["readDraftCollection"] = (
        draft,
        scope,
        collection,
    ) => {
        if (!bindings.lookupCollection(collection)) {
            throw new TypeError(
                "Collection draft read requires a valid collection",
            )
        }
        const lane = laneFor(draft)
        const revision = lane.revisionByCollection.get(collection) ?? 0
        let byCollection = lane.membershipMemo.get(scope)
        const current = byCollection?.get(collection)
        if (current?.revision === revision) return current.rows
        if (
            lane.rebased !== undefined &&
            (rebaseFor(lane, scope, collection) !== undefined ||
                followsRebase(draft, lane, scope, collection))
        ) {
            let next: readonly CollectionRowHandle[]
            if (rebaseFor(lane, scope, collection) !== undefined) {
                const top = restoreChainTop(draft, lane, scope, collection)
                next = rebasedRows(
                    lane,
                    scope,
                    collection,
                    membershipRows(materializeMembership(top, collection)),
                    top,
                )
            } else next = readDraftCollection(draft, scope.parent!, collection)
            // Same identity rules as ordinary draft reads: the committed array
            // or the previous draft snapshot when the ordered rows are equal.
            const committedRows = membershipRows(
                materializeMembership(scope, collection),
            )
            const rows = sameRowsWhileProducingSnapshot(
                scope,
                committedRows,
                next,
            )
                ? committedRows
                : current !== undefined &&
                    sameRowsWhileProducingSnapshot(scope, current.rows, next)
                  ? current.rows
                  : Object.freeze([...next])
            if (byCollection === undefined) {
                byCollection = new Map()
                lane.membershipMemo.set(scope, byCollection)
            }
            byCollection.set(collection, { revision, rows })
            return rows
        }

        const baseline =
            readBaselineOverride === undefined &&
            typeof scope.createOutcomeToken === "function"
                ? membershipRows(materializeMembership(scope, collection))
                : EMPTY_ROWS
        const candidates = new Map<CollectionRowHandle, DraftCoordinate>()
        const history = lane.historyByCollectionScope.get(collection)
        let routeScope: StoreScopeNode | undefined = scope
        while (routeScope !== undefined) {
            for (const event of history?.get(routeScope) ?? []) {
                if (!candidates.has(event.row)) {
                    candidates.set(
                        event.row,
                        coordinateFor(draft, scope, event.row, collection),
                    )
                }
            }
            routeScope = routeScope.parent
        }
        const rows: CollectionRowHandle[] = []
        if (baseline.length) {
            recordCounter(
                scope,
                COLLECTION_MEMBERSHIP_ROWS_SCANNED,
                baseline.length,
            )
        }
        for (const row of baseline) {
            const coordinate = candidates.get(row)
            if (
                coordinate === undefined ||
                coordinate.enablingBirth === BASELINE_BIRTH
            ) {
                rows.push(row)
            }
        }
        const births: DraftCoordinate[] = []
        if (candidates.size !== 0) {
            recordCounter(
                scope,
                COLLECTION_MEMBERSHIP_ROWS_SCANNED,
                candidates.size,
            )
        }
        for (const coordinate of candidates.values()) {
            if (
                typeof coordinate.enablingBirth === "number" &&
                draftOutcome(
                    lane,
                    coordinate.scope,
                    coordinate.row,
                    coordinate.collection,
                ).kind === "present"
            ) {
                births.push(coordinate)
            }
        }
        births.sort((first, second) => {
            const firstBirth = first.enablingBirth
            const secondBirth = second.enablingBirth
            if (firstBirth === secondBirth) {
                return first.discoveryIndex - second.discoveryIndex
            }
            return (firstBirth as number) - (secondBirth as number)
        })
        for (const coordinate of births) rows.push(coordinate.row)
        let snapshot: readonly CollectionRowHandle[]
        if (sameRowsWhileProducingSnapshot(scope, baseline, rows)) {
            snapshot = baseline
        } else if (
            current !== undefined &&
            sameRowsWhileProducingSnapshot(scope, current.rows, rows)
        ) {
            snapshot = current.rows
        } else {
            snapshot = Object.freeze(rows)
            recordCounter(scope, COLLECTION_MEMBERSHIP_ARRAY_ALLOCATIONS)
        }
        if (byCollection === undefined) {
            byCollection = new Map()
            lane.membershipMemo.set(scope, byCollection)
        }
        byCollection.set(
            collection,
            Object.freeze({ revision, rows: snapshot }),
        )
        return snapshot
    }

    const inspectDraft: CollectionDraftKernel["inspectDraft"] = draft => {
        const lane = lanes.get(draft)
        if (lane === undefined) return undefined
        let membershipMemoCount = 0
        for (const byCollection of lane.membershipMemo.values()) {
            membershipMemoCount += byCollection.size
        }
        const revisionSnapshot = new WeakMap<
            CollectionHandle,
            Readonly<{ value: number }>
        >()
        for (const [collection, revision] of lane.revisionByCollection) {
            revisionSnapshot.set(collection, Object.freeze({ value: revision }))
        }
        const inspectCoordinate = (coordinate: DraftCoordinate) =>
            Object.freeze({
                id: coordinate.discoveryIndex,
                baselineLocal: coordinate.baseline.local.kind,
                baselineEffective: coordinate.baseline.effective.kind,
                baselineInherited: coordinate.baseline.inherited.kind,
                final: coordinate.final?.kind,
                enablingBirth:
                    coordinate.enablingBirth === BASELINE_BIRTH
                        ? ("baseline" as const)
                        : coordinate.enablingBirth,
            })
        return Object.freeze({
            discoveryOrder: Object.freeze(
                [...lane.byScope.values()]
                    .flatMap(coordinates => [...coordinates.values()])
                    .sort(
                        (first, second) =>
                            first.discoveryIndex - second.discoveryIndex,
                    )
                    .map(inspectCoordinate),
            ),
            planOrder: Object.freeze(lane.planOrder.map(inspectCoordinate)),
            history: Object.freeze(
                lane.history.map(event =>
                    Object.freeze({
                        coordinateId: event.coordinateId,
                        kind: event.kind,
                        sequence: event.sequence,
                    }),
                ),
            ),
            membershipMemoCount,
            revision: (collection: CollectionHandle): number =>
                revisionSnapshot.get(collection)?.value ?? 0,
        })
    }

    const planCommit = (
        draftValue: object,
    ): CollectionCommitPlan | undefined => {
        const draft = draftValue as TreeDraft
        if (!draft.hasRows) return undefined
        const lane = lanes.get(draft)
        if (lane === undefined) {
            throw new Error("Collection row draft lane is missing")
        }

        let orderedNodes: MembershipPlanNode[] | undefined
        const rows: RowApplyPlan[] = []
        const rowSettlements: RowSettlementPlan[] = []
        const membershipInstalls: MembershipPlanNode[] = []
        const membershipSettlements: MembershipSettlementPlan[] = []
        let historyMarks:
            | {
                  scope: StoreScopeNode
                  collection: CollectionHandle
                  history: boolean
              }[]
            | undefined
        const considered = new WeakSet<RowViewRecord>()
        const nodesByRecord = new WeakMap<
            MembershipRecord,
            MembershipPlanNode
        >()
        const nodesByScope = new Map<
            StoreScopeNode,
            Map<CollectionHandle, MembershipPlanNode>
        >()
        const collectionSlots: {
            readonly collection: CollectionHandle
            top: MembershipPlanNode | undefined
        }[] = []
        const slotsByCollection = new Map<
            CollectionHandle,
            (typeof collectionSlots)[number]
        >()
        type MembershipPresenceTransition =
            MembershipPresenceTimeline["transitions"][number]
        const noMembershipTransitions = Object.freeze(
            [],
        ) as readonly MembershipPresenceTransition[]
        const absentMembershipTimeline: MembershipPresenceTimeline = {
            baselinePresent: false,
            transitions: noMembershipTransitions,
            birth: undefined,
        }
        const presentMembershipTimeline: MembershipPresenceTimeline = {
            baselinePresent: true,
            transitions: noMembershipTransitions,
            birth: BASELINE_BIRTH,
        }
        const placementsByNode = new Map<
            MembershipPlanNode,
            Map<CollectionRowHandle, MembershipPresenceTimeline>
        >()
        const baselineRowsByNode = new Map<
            MembershipPlanNode,
            Set<CollectionRowHandle>
        >()

        const rememberNode = (node: MembershipPlanNode): void => {
            let byCollection = nodesByScope.get(node.scope)
            if (byCollection === undefined) {
                byCollection = new Map()
                nodesByScope.set(node.scope, byCollection)
            }
            byCollection.set(node.atom, node)
            if (node.existing !== undefined) {
                nodesByRecord.set(node.existing, node)
            }
        }

        const nodeForRecord = (
            target: MembershipRecord,
        ): MembershipPlanNode => {
            const current = nodesByRecord.get(target)
            if (current !== undefined) return current
            const unresolved: MembershipRecord[] = []
            let record: MembershipRecord | undefined = target
            let parent: MembershipPlanNode | undefined
            while (record !== undefined) {
                recordCounter(record.scope, COLLECTION_MEMBERSHIP_ROUTE_VISITS)
                const known = nodesByRecord.get(record)
                if (known !== undefined) {
                    parent = known
                    break
                }
                unresolved.push(record)
                record = record.inheritedFrom
            }
            for (let index = unresolved.length - 1; index >= 0; index--) {
                const existing = unresolved[index] as MembershipRecord
                const node: MembershipPlanNode = {
                    scope: existing.scope,
                    atom: existing.atom,
                    existing,
                    parent,
                    beforeRows:
                        existing.ordered === undefined
                            ? membershipRows(existing)
                            : EMPTY_ROWS,
                    plannedChildren: [],
                    finalRows: undefined,
                    membershipChangedFromBefore: undefined,
                    installed: undefined,
                    affected: false,
                    containsAffected: false,
                }
                if (existing.ordered !== undefined) {
                    let snapshot: readonly CollectionRowHandle[] | undefined
                    Object.defineProperty(node, "beforeRows", {
                        get: () => (snapshot ??= membershipRows(existing)),
                    })
                }
                rememberNode(node)
                parent = node
            }
            return parent as MembershipPlanNode
        }

        const ensureMembershipPath = (
            scope: StoreScopeNode,
            collection: CollectionHandle,
        ): MembershipPlanNode => {
            const known = nodesByScope.get(scope)?.get(collection)
            // A memo hit is only the target map lookup; no ancestry route node
            // is entered again, even when another row shares this plan path.
            if (known !== undefined) return known
            const unresolved: StoreScopeNode[] = []
            let currentScope: StoreScopeNode | undefined = scope
            let parent: MembershipPlanNode | undefined
            while (currentScope !== undefined) {
                const planned = nodesByScope.get(currentScope)?.get(collection)
                if (planned !== undefined) {
                    recordCounter(
                        currentScope,
                        COLLECTION_MEMBERSHIP_ROUTE_VISITS,
                    )
                    parent = planned
                    break
                }
                const existing = scopeSidecars
                    .get(currentScope)
                    ?.memberships?.get(collection)
                if (existing !== undefined) {
                    parent = nodeForRecord(existing)
                    break
                }
                recordCounter(currentScope, COLLECTION_MEMBERSHIP_ROUTE_VISITS)
                unresolved.push(currentScope)
                currentScope = currentScope.parent
            }
            for (let index = unresolved.length - 1; index >= 0; index--) {
                const node: MembershipPlanNode = {
                    scope: unresolved[index] as StoreScopeNode,
                    atom: collection,
                    existing: undefined,
                    parent,
                    beforeRows: parent?.beforeRows ?? EMPTY_ROWS,
                    plannedChildren: [],
                    finalRows: undefined,
                    membershipChangedFromBefore: undefined,
                    installed: undefined,
                    affected: false,
                    containsAffected: false,
                }
                parent?.plannedChildren.push(node)
                membershipInstalls.push(node)
                rememberNode(node)
                parent = node
            }
            return parent as MembershipPlanNode
        }

        const collectionSlot = (collection: CollectionHandle) => {
            let slot = slotsByCollection.get(collection)
            if (slot !== undefined) return slot
            slot = { collection, top: undefined }
            slotsByCollection.set(collection, slot)
            collectionSlots.push(slot)
            return slot
        }

        const markAffected = (
            slot: (typeof collectionSlots)[number],
            node: MembershipPlanNode,
        ): void => {
            node.affected = true
            const previousTop = slot.top
            if (previousTop === undefined) slot.top = node
            let firstPreviouslyMarked: MembershipPlanNode | undefined
            let current: MembershipPlanNode | undefined = node
            while (current !== undefined) {
                if (current.containsAffected) {
                    firstPreviouslyMarked ??= current
                    if (Object.is(current, previousTop)) return
                } else {
                    current.containsAffected = true
                }
                current = current.parent
            }
            if (previousTop !== undefined) {
                slot.top = firstPreviouslyMarked as MembershipPlanNode
            }
        }

        const baselineContains = (
            node: MembershipPlanNode,
            row: CollectionRowHandle,
        ): boolean => {
            if (node.existing?.ordered !== undefined)
                return node.existing.ordered.entries.has(row)
            let rows = baselineRowsByNode.get(node)
            if (rows === undefined) {
                if (node.beforeRows.length) {
                    recordCounter(
                        node.scope,
                        COLLECTION_MEMBERSHIP_ROWS_SCANNED,
                        node.beforeRows.length,
                    )
                }
                rows = new Set(node.beforeRows)
                baselineRowsByNode.set(node, rows)
            }
            return rows.has(row)
        }

        const mergeMembershipTimeline = (
            node: MembershipPlanNode,
            row: CollectionRowHandle,
            parent: MembershipPresenceTimeline,
            events: readonly PresenceEvent[] | undefined,
        ): MembershipPresenceTimeline => {
            if (membershipPlacementTraceForTest !== undefined) {
                membershipPlacementTraceForTest.states++
            }
            let local = committedLocal(node.scope, row).kind
            if (events === undefined) {
                return local === "none"
                    ? parent
                    : local === "present"
                      ? presentMembershipTimeline
                      : absentMembershipTimeline
            }

            let parentPresent = parent.baselinePresent
            let present =
                local === "present" || (local === "none" && parentPresent)
            const baselinePresent = present
            let birth: EnablingBirth | undefined = present
                ? BASELINE_BIRTH
                : undefined
            const transitions: MembershipPresenceTransition[] = []
            let parentIndex = 0
            let eventIndex = 0
            while (
                parentIndex < parent.transitions.length ||
                eventIndex < events.length
            ) {
                const parentTransition = parent.transitions[parentIndex]
                const event = events[eventIndex]
                let sequence: number
                if (
                    parentTransition !== undefined &&
                    (event === undefined ||
                        parentTransition.sequence < event.sequence)
                ) {
                    parentPresent = parentTransition.present
                    sequence = parentTransition.sequence
                    parentIndex++
                } else {
                    local =
                        event!.kind === "present"
                            ? "present"
                            : event!.kind === "absent"
                              ? "absent"
                              : "none"
                    sequence = event!.sequence
                    eventIndex++
                }
                const nextPresent =
                    local === "present" || (local === "none" && parentPresent)
                if (nextPresent === present) continue
                present = nextPresent
                birth = present ? sequence : undefined
                transitions.push({ sequence, present })
            }
            if (!transitions.length) {
                return present
                    ? presentMembershipTimeline
                    : absentMembershipTimeline
            }
            return { baselinePresent, transitions, birth }
        }

        const placementsFor = (
            target: MembershipPlanNode,
        ): Map<CollectionRowHandle, MembershipPresenceTimeline> => {
            const known = placementsByNode.get(target)
            if (known !== undefined) return known
            const unresolved: MembershipPlanNode[] = []
            let current: MembershipPlanNode | undefined = target
            while (current !== undefined && !placementsByNode.has(current)) {
                unresolved.push(current)
                current = current.parent
            }
            let parentPlacements =
                current === undefined
                    ? new Map<CollectionRowHandle, MembershipPresenceTimeline>()
                    : (placementsByNode.get(current) as Map<
                          CollectionRowHandle,
                          MembershipPresenceTimeline
                      >)
            for (let index = unresolved.length - 1; index >= 0; index--) {
                const node = unresolved[index] as MembershipPlanNode
                const eventsByRow = new Map<
                    CollectionRowHandle,
                    PresenceEvent[]
                >()
                for (const event of lane.historyByCollectionScope
                    .get(node.atom)
                    ?.get(node.scope) ?? []) {
                    let events = eventsByRow.get(event.row)
                    if (events === undefined) {
                        events = []
                        eventsByRow.set(event.row, events)
                    }
                    events.push(event)
                }
                const placements = new Map<
                    CollectionRowHandle,
                    MembershipPresenceTimeline
                >()
                if (parentPlacements.size !== 0) {
                    recordCounter(
                        node.scope,
                        COLLECTION_MEMBERSHIP_ROWS_SCANNED,
                        parentPlacements.size,
                    )
                }
                for (const [row, parentTimeline] of parentPlacements) {
                    placements.set(
                        row,
                        mergeMembershipTimeline(
                            node,
                            row,
                            parentTimeline,
                            eventsByRow.get(row),
                        ),
                    )
                    eventsByRow.delete(row)
                }
                for (const [row, events] of eventsByRow) {
                    const parentTimeline =
                        node.parent !== undefined &&
                        baselineContains(node.parent, row)
                            ? presentMembershipTimeline
                            : absentMembershipTimeline
                    placements.set(
                        row,
                        mergeMembershipTimeline(
                            node,
                            row,
                            parentTimeline,
                            events,
                        ),
                    )
                }
                placementsByNode.set(node, placements)
                parentPlacements = placements
            }
            return placementsByNode.get(target) as Map<
                CollectionRowHandle,
                MembershipPresenceTimeline
            >
        }

        const isFollowerNode = (node: MembershipPlanNode): boolean =>
            (node.follower ??=
                node.rebase === undefined &&
                node.parent !== undefined &&
                (node.parent.rebase !== undefined ||
                    isFollowerNode(node.parent)) &&
                mirrorsParent(
                    lane,
                    node.scope,
                    node.atom,
                    node.beforeRows,
                    node.parent.beforeRows,
                    () => finalRowsFor(node.parent!),
                ))

        /** Rebased scopes take an untouched child's order; followers copy it. */
        const restoredRowsFor = (
            node: MembershipPlanNode,
        ): readonly CollectionRowHandle[] | undefined => {
            if (lane.rebased === undefined) return undefined
            let rows: readonly CollectionRowHandle[]
            if (node.rebase !== undefined) {
                // Same restore chain as draft reads: skip rebased AND following
                // ancestors, whose committed order is stale this transaction.
                let base = node.parent!
                while (base.rebase !== undefined || isFollowerNode(base))
                    base = base.parent!
                rows = rebasedRows(
                    lane,
                    node.scope,
                    node.atom,
                    base.beforeRows,
                    base.scope,
                )
            } else if (isFollowerNode(node)) {
                // A rebased or following parent always resolves to real rows.
                rows = finalRowsFor(node.parent!)
            } else return undefined
            const before = node.beforeRows
            const changed = !sameRowsWhileProducingSnapshot(
                node.scope,
                before,
                rows,
            )
            node.membershipChangedFromBefore = changed
            node.finalRows =
                node.existing !== undefined && !changed
                    ? before
                    : Object.freeze([...rows])
            if (
                changed &&
                node.existing !== undefined &&
                extensionRecorder(node.scope) !== undefined
            )
                node.membershipChanges = restoredMembershipChanges(
                    before,
                    node.finalRows,
                )
            if (node.existing?.ordered !== undefined && changed) {
                node.orderedRebuild = node.finalRows
                ;(orderedNodes ??= []).push(node)
            }
            return node.finalRows
        }

        const finalRowsFor = (
            node: MembershipPlanNode,
        ): readonly CollectionRowHandle[] => {
            if (node.finalRows !== undefined) return node.finalRows
            const restored = restoredRowsFor(node)
            if (restored !== undefined) return restored
            if (node.existing?.ordered !== undefined) {
                const placements = placementsFor(node)
                const removals: object[] = []
                const births: { row: object; birth: number }[] = []
                for (const [row, placement] of placements) {
                    if (
                        placement.baselinePresent &&
                        placement.birth !== BASELINE_BIRTH
                    )
                        removals.push(row)
                    if (typeof placement.birth === "number")
                        births.push({ row, birth: placement.birth })
                }
                births.sort((a, b) => a.birth - b.birth)
                const born = births.map(item => item.row)
                node.membershipChangedFromBefore =
                    node.existing.ordered.changes(removals, born)
                node.orderedPatch = { removals, births: born }
                ;(orderedNodes ??= []).push(node)
                node.membershipChanges = placements
                // The ordered patch is applied only after all preflight callbacks pass.
                return EMPTY_ROWS
            }
            if (node.existing !== undefined) {
                membershipRebuildTraceForTest?.push(node.existing)
            }
            const next: CollectionRowHandle[] = []
            const births: {
                readonly row: CollectionRowHandle
                readonly birth: number
            }[] = []
            const captureMembershipChanges =
                node.existing !== undefined &&
                extensionRecorder(node.scope) !== undefined
            let classifiedPlacements:
                | Map<CollectionRowHandle, MembershipPresenceTimeline>
                | undefined
            if (readBaselineOverride === undefined) {
                const placements = placementsFor(node)
                if (captureMembershipChanges) {
                    classifiedPlacements = placements
                }
                if (node.beforeRows.length) {
                    recordCounter(
                        node.scope,
                        COLLECTION_MEMBERSHIP_ROWS_SCANNED,
                        node.beforeRows.length,
                    )
                }
                for (const row of node.beforeRows) {
                    const placement = placements.get(row)
                    if (
                        placement === undefined ||
                        placement.birth === BASELINE_BIRTH
                    ) {
                        next.push(row)
                    }
                }
                if (placements.size !== 0) {
                    recordCounter(
                        node.scope,
                        COLLECTION_MEMBERSHIP_ROWS_SCANNED,
                        placements.size,
                    )
                }
                for (const [row, placement] of placements) {
                    if (
                        classifiedPlacements !== undefined &&
                        ((placement.baselinePresent &&
                            placement.birth === undefined) ||
                            (!placement.baselinePresent &&
                                typeof placement.birth === "number"))
                    ) {
                        node.membershipChanges = classifiedPlacements
                    }
                    if (typeof placement.birth === "number") {
                        births.push({ row, birth: placement.birth })
                    }
                }
            } else {
                const candidates = new Map<
                    CollectionRowHandle,
                    DraftCoordinate
                >()
                const history = lane.historyByCollectionScope.get(node.atom)
                let currentScope: StoreScopeNode | undefined = node.scope
                while (currentScope !== undefined) {
                    for (const event of history?.get(currentScope) ?? []) {
                        if (!candidates.has(event.row)) {
                            candidates.set(
                                event.row,
                                coordinateFor(
                                    draft,
                                    node.scope,
                                    event.row,
                                    node.atom,
                                ),
                            )
                        }
                    }
                    currentScope = currentScope.parent
                }
                if (node.beforeRows.length) {
                    recordCounter(
                        node.scope,
                        COLLECTION_MEMBERSHIP_ROWS_SCANNED,
                        node.beforeRows.length,
                    )
                }
                for (const row of node.beforeRows) {
                    const coordinate = candidates.get(row)
                    if (
                        coordinate === undefined ||
                        coordinate.enablingBirth === BASELINE_BIRTH
                    ) {
                        next.push(row)
                    }
                }
                if (candidates.size !== 0) {
                    recordCounter(
                        node.scope,
                        COLLECTION_MEMBERSHIP_ROWS_SCANNED,
                        candidates.size,
                    )
                }
                for (const coordinate of candidates.values()) {
                    if (
                        typeof coordinate.enablingBirth === "number" &&
                        draftOutcome(
                            lane,
                            coordinate.scope,
                            coordinate.row,
                            coordinate.collection,
                        ).kind === "present"
                    ) {
                        births.push({
                            row: coordinate.row,
                            birth: coordinate.enablingBirth,
                        })
                    }
                }
            }
            births.sort((first, second) => {
                return first.birth - second.birth
            })
            for (const birth of births) next.push(birth.row)
            const membershipChangedFromBefore = !sameRowsWhileProducingSnapshot(
                node.scope,
                node.beforeRows,
                next,
            )
            node.membershipChangedFromBefore = membershipChangedFromBefore
            if (node.existing !== undefined && !membershipChangedFromBefore) {
                node.finalRows = node.beforeRows
            } else {
                node.finalRows = Object.freeze(next)
                recordCounter(
                    node.scope,
                    COLLECTION_MEMBERSHIP_ARRAY_ALLOCATIONS,
                )
            }
            return node.finalRows
        }

        for (const coordinate of lane.planOrder) {
            const final = coordinate.final
            if (final === undefined) continue
            recordCounter(
                coordinate.scope,
                COLLECTION_ROW_FINAL_RESOLUTION_VISITS,
            )
            const local =
                final.kind === "present"
                    ? presentLocal(final.value)
                    : final.kind === "absent" &&
                        coordinate.scope.parent !== undefined
                      ? ABSENT_LOCAL
                      : NONE
            const ownershipChanged = !sameLocal(
                committedLocal(coordinate.scope, coordinate.row),
                local,
            )
            rows.push(Object.freeze({ coordinate, local, ownershipChanged }))

            const slot = collectionSlot(coordinate.collection)
            const baseline = freezeBaseline(
                readBaseline(
                    coordinate.scope,
                    coordinate.row,
                    coordinate.collection,
                ),
            )
            const localKindChanged = baseline.local.kind !== local.kind
            if (localKindChanged) {
                ensureMembershipPath(coordinate.scope, coordinate.collection)
                if (coordinate.scope.parent !== undefined) {
                    ;(historyMarks ??= []).push({
                        scope: coordinate.scope,
                        collection: coordinate.collection,
                        history: true,
                    })
                }
            }
            const baselinePlacement =
                baseline.effective.kind === "present"
                    ? BASELINE_BIRTH
                    : undefined
            if (!Object.is(baselinePlacement, coordinate.enablingBirth)) {
                markAffected(
                    slot,
                    ensureMembershipPath(
                        coordinate.scope,
                        coordinate.collection,
                    ),
                )
                // A row that left and returned within this draft (delete then
                // reset) moves without changing ownership; the scope's order
                // now has its own history, which a bulk reset must restore.
                if (!localKindChanged && coordinate.scope.parent !== undefined)
                    (historyMarks ??= []).push({
                        scope: coordinate.scope,
                        collection: coordinate.collection,
                        history: true,
                    })
            }

            const materialized = scopeSidecars
                .get(coordinate.scope)
                ?.rowViews?.get(coordinate.row)
            if (materialized === undefined) continue
            const pending = [materialized]
            while (pending.length) {
                const record = pending.pop() as RowViewRecord
                if (considered.has(record)) continue
                considered.add(record)
                recordCounter(record.scope, COLLECTION_ROW_ROUTE_VISITS)
                const before =
                    record.served.outcome.kind === "value" &&
                    record.served.outcome.value !== undefined
                        ? presentOutcome(record.served.outcome.value)
                        : ABSENT
                const after = draftOutcome(
                    lane,
                    record.scope,
                    record.atom,
                    coordinate.collection,
                )
                if (sameOutcome(before, after)) continue
                rowSettlements.push(
                    Object.freeze({
                        scope: record.scope,
                        atom: record.atom as AnyState,
                        record,
                        before,
                        outcome: after,
                    }),
                )
                const children: RowViewRecord[] = []
                record.inheritingChildren.forEach(child => {
                    record.scope.coordinator.recordCounter(
                        StoreTreeCounterId.routeVisits,
                    )
                    children.push(child)
                })
                for (let index = children.length - 1; index >= 0; index--) {
                    pending.push(children[index] as RowViewRecord)
                }
            }
        }

        if (lane.rebased !== undefined)
            for (const [scope, marker] of lane.rebased) {
                const scopeHistory = lane.historyByCollectionScope
                for (const collection of marker.collections) {
                    const node = ensureMembershipPath(scope, collection)
                    node.rebase = marker
                    markAffected(collectionSlot(collection), node)
                    // Order stays parent-aligned unless the scope re-owned
                    // collection rows after the reset.
                    ;(historyMarks ??= []).push({
                        scope,
                        collection,
                        history: (
                            scopeHistory.get(collection)?.get(scope) ?? []
                        ).some(event => event.sequence >= marker.end),
                    })
                }
            }
        // A descendant of a restored scope that staged row events of its own
        // keeps its order history (the mirror rule), even when the events
        // cancel out. Plan it, so that order is installed and recorded as its
        // own rather than lazily re-inherited from the restored parent when
        // its membership was never materialized.
        if (lane.rebased !== undefined)
            for (const [collection, byScope] of lane.historyByCollectionScope) {
                if (!restoringCollection(lane, collection)) continue
                for (const [scope, events] of byScope) {
                    if (
                        events.length === 0 ||
                        rebaseFor(lane, scope, collection) !== undefined ||
                        !hasRestoredAncestor(lane, scope, collection)
                    )
                        continue
                    markAffected(
                        collectionSlot(collection),
                        ensureMembershipPath(scope, collection),
                    )
                    ;(historyMarks ??= []).push({
                        scope,
                        collection,
                        history: true,
                    })
                }
            }

        for (const slot of collectionSlots) {
            const top = slot.top
            if (top === undefined) continue
            const visited = new Set<MembershipPlanNode>()
            const pending: {
                readonly node: MembershipPlanNode
                readonly affected: boolean
            }[] = [{ node: top, affected: false }]
            while (pending.length) {
                const entry = pending.pop()!
                const node = entry.node
                if (visited.has(node)) continue
                visited.add(node)
                recordCounter(node.scope, COLLECTION_MEMBERSHIP_ROUTE_VISITS)
                const affected = entry.affected || node.affected
                if (affected) {
                    const finalRows = finalRowsFor(node)
                    if (
                        node.existing !== undefined &&
                        (node.orderedPatch !== undefined
                            ? node.membershipChangedFromBefore
                            : !Object.is(finalRows, node.beforeRows))
                    ) {
                        membershipSettlements.push(
                            Object.freeze({
                                scope: node.scope,
                                atom: node.atom as AnyState,
                                node,
                                record: node.existing,
                                rows: finalRows,
                            }),
                        )
                    }
                }
                const children: MembershipPlanNode[] = []
                node.existing?.inheritingChildren.forEach(child => {
                    node.scope.coordinator.recordCounter(
                        StoreTreeCounterId.routeVisits,
                    )
                    const childNode = affected
                        ? nodeForRecord(child)
                        : nodesByRecord.get(child)
                    if (
                        childNode !== undefined &&
                        (affected || childNode.containsAffected)
                    ) {
                        children.push(childNode)
                    }
                })
                for (const child of node.plannedChildren) {
                    if (affected || child.containsAffected) children.push(child)
                }
                for (let index = children.length - 1; index >= 0; index--) {
                    pending.push({
                        node: children[index] as MembershipPlanNode,
                        affected,
                    })
                }
            }
        }
        for (const node of membershipInstalls) {
            if (node.finalRows !== undefined) continue
            if (node.parent === undefined) {
                finalRowsFor(node)
                continue
            }
            node.finalRows = node.beforeRows
            node.membershipChangedFromBefore = false
        }
        let indexPlan: ScopedCollectionCommitPlan["indexPlan"]
        const rebuilt =
            lane.rebased === undefined
                ? undefined
                : orderedNodes?.filter(
                      node => node.orderedRebuild !== undefined,
                  )
        if (
            indexes !== undefined &&
            (lane.planOrder.some(coordinate =>
                indexes!.active(coordinate.collection),
            ) ||
                rebuilt?.some(node => indexes!.active(node.atom)))
        ) {
            const changed = new Map<MembershipRecord, Set<object>>()
            for (const coordinate of lane.planOrder) {
                if (!indexes.active(coordinate.collection)) continue
                const root = scopeSidecars
                    .get(coordinate.scope)
                    ?.memberships?.get(coordinate.collection)
                if (root === undefined) continue
                const pending = [root]
                while (pending.length) {
                    const record = pending.pop()!
                    // Index activation marks the entire ancestry path. An
                    // unmarked membership subtree cannot contain an index.
                    if (record.ordered === undefined) continue
                    recordCounter(record.scope, COLLECTION_INDEX_ROUTE_VISITS)
                    let rows = changed.get(record)
                    if (rows === undefined)
                        changed.set(record, (rows = new Set()))
                    rows.add(coordinate.row)
                    record.indexedChildren?.forEach(child =>
                        pending.push(child),
                    )
                }
            }
            const deltas: IndexScopeDelta[] = []
            for (const node of rebuilt ?? []) {
                // A rebuilt order re-ranks every row from the current nextRank.
                const record = node.existing!
                const ordered = record.ordered!
                const ranks = new Map<object, number>()
                node.orderedRebuild!.forEach((row, index) =>
                    ranks.set(row, ordered.nextRank + index),
                )
                const changes = []
                for (const row of new Set([
                    ...ordered.entries.keys(),
                    ...node.orderedRebuild!,
                ])) {
                    const before = committedOutcome(record.scope, row)
                    const after = draftOutcome(
                        lane,
                        record.scope,
                        row,
                        record.atom,
                    )
                    changes.push({
                        row,
                        before:
                            before.kind === "present"
                                ? before.value
                                : undefined,
                        after:
                            after.kind === "present" ? after.value : undefined,
                        rank: ranks.get(row),
                    })
                }
                if (changes.length)
                    deltas.push({
                        scope: record.scope,
                        collection: record.atom,
                        changes,
                    })
            }
            for (const [record, rows] of changed) {
                if (record.ordered === undefined) continue
                if (nodesByRecord.get(record)?.orderedRebuild !== undefined)
                    continue
                const node = nodeForRecord(record)
                // A restore-derived record whose order is unchanged keeps its
                // ranks: discarded pre-reset births must not re-rank rows.
                const restored =
                    lane.rebased !== undefined &&
                    (node.rebase !== undefined || isFollowerNode(node))
                const placements = restored ? undefined : placementsFor(node)
                const changes = []
                for (const row of rows) {
                    const before = committedOutcome(record.scope, row)
                    const after = draftOutcome(
                        lane,
                        record.scope,
                        row,
                        record.atom,
                    )
                    const birth = placements?.get(row)?.birth
                    if (sameOutcome(before, after) && typeof birth !== "number")
                        continue
                    changes.push({
                        row,
                        before:
                            before.kind === "present"
                                ? before.value
                                : undefined,
                        after:
                            after.kind === "present" ? after.value : undefined,
                        rank:
                            after.kind === "absent"
                                ? undefined
                                : typeof birth === "number"
                                  ? record.ordered.nextRank + birth
                                  : record.ordered.entries.get(row)?.rank,
                    })
                }
                if (changes.length)
                    deltas.push({
                        scope: record.scope,
                        collection: record.atom,
                        changes,
                    })
            }
            indexPlan = indexes.prepare(deltas)
        }
        const plan: ScopedCollectionCommitPlan = {
            commit: commitPlan,
            indexPlan,
            orderedNodes,
            historyMarks,
            rows: Object.freeze(rows),
            rowSettlements: Object.freeze(rowSettlements),
            membershipInstalls: Object.freeze(membershipInstalls),
            membershipSettlements: Object.freeze(membershipSettlements),
            sources: Object.freeze([
                ...rowSettlements,
                ...membershipSettlements,
            ]),
        }
        return plan
    }

    const applyCommit = (planValue: CollectionCommitPlan): boolean => {
        const plan = planValue as ScopedCollectionCommitPlan
        let ownershipChanged = false
        for (const settlement of plan.rowSettlements) {
            const { record, before, outcome: after } = settlement
            recordCounter(record.scope, COLLECTION_EFFECTIVE_DELTAS_PREPARED)
            recordDetail(
                record.scope,
                before.kind === "absent"
                    ? COLLECTION_EFFECTIVE_INSERT
                    : after.kind === "absent"
                      ? COLLECTION_EFFECTIVE_REMOVE
                      : COLLECTION_EFFECTIVE_UPDATE,
                record.atom,
                bindings.lookupRow(record.atom),
            )
        }
        for (const settlement of plan.membershipSettlements) {
            for (const [row, placement] of settlement.node.membershipChanges ??
                []) {
                const code =
                    placement.baselinePresent && placement.birth === undefined
                        ? COLLECTION_MEMBERSHIP_REMOVE
                        : !placement.baselinePresent &&
                            typeof placement.birth === "number"
                          ? COLLECTION_MEMBERSHIP_INSERT
                          : undefined
                if (code !== undefined) {
                    recordDetail(
                        settlement.node.scope,
                        code,
                        row,
                        settlement.node.atom,
                    )
                }
            }
        }
        for (const rowPlan of plan.rows) {
            const operation = rowPlan.coordinate.finalOperation
            if (operation !== undefined) {
                recordDetail(
                    rowPlan.coordinate.scope,
                    operation === "set"
                        ? COLLECTION_INTENT_SET
                        : operation === "update"
                          ? COLLECTION_INTENT_UPDATE
                          : operation === "reset"
                            ? COLLECTION_INTENT_RESET
                            : COLLECTION_INTENT_DELETE,
                    rowPlan.coordinate.row,
                    rowPlan.coordinate.collection,
                )
            }
            if (!rowPlan.ownershipChanged) continue
            ownershipChanged = true
            const { row, scope } = rowPlan.coordinate
            if (rowPlan.local.kind === "none") {
                const sidecar = scopeSidecars.get(scope)
                sidecar?.rowLocals?.delete(row)
                if (sidecar?.ownedRows?.delete(row)) {
                    recordCounter(scope, COLLECTION_OWNER_RELEASES)
                }
                if (sidecar?.ownedRows?.size === 0) {
                    sidecar.ownedRows = undefined
                    sidecar.rowLocals = undefined
                    if (
                        sidecar.liveRowViews === undefined &&
                        sidecar.liveMemberships === undefined
                    ) {
                        scopeSidecars.delete(scope)
                    }
                }
                continue
            }
            const sidecar = sidecarFor(scope)
            let rowLocals = sidecar.rowLocals
            if (rowLocals === undefined) {
                rowLocals = new WeakMap()
                sidecar.rowLocals = rowLocals
            }
            let ownedRows = sidecar.ownedRows
            if (ownedRows === undefined) {
                ownedRows = new Set()
                sidecar.ownedRows = ownedRows
                recordCounter(scope, COLLECTION_OWNER_RETENTION_SETS_CREATED)
            }
            rowLocals.set(row, rowPlan.local)
            if (!ownedRows.has(row)) {
                ownedRows.add(row)
                recordCounter(scope, COLLECTION_OWNER_RETAINS)
            }
        }
        for (const node of plan.membershipInstalls) {
            node.installed = registerMembershipRecord(
                node.scope,
                node.atom,
                node.finalRows as readonly CollectionRowHandle[],
                node.parent !== undefined && node.finalRows === node.beforeRows,
            )
        }
        for (const node of plan.orderedNodes ?? []) {
            const record = node.existing!
            if (node.orderedRebuild !== undefined) {
                const ordered = record.ordered!
                const nextRank = ordered.nextRank
                ordered.entries.clear()
                ordered.tail = undefined
                ordered.nextRank = nextRank
                for (const row of node.orderedRebuild) ordered.append(row)
                record.snapshotDirty = true
                record.served = servedMembership(
                    record.scope,
                    EMPTY_ROWS,
                    record.served.token,
                )
                continue
            }
            const patch = node.orderedPatch!
            if (!node.membershipChangedFromBefore) continue
            for (const row of patch.removals) record.ordered!.remove(row)
            for (const row of patch.births) record.ordered!.append(row)
            record.snapshotDirty = true
            // The old immutable array may pin deleted rows even when nobody
            // reads collection membership again. Readers already hold their
            // own snapshots; discard the record's stale copy immediately.
            record.served = servedMembership(
                record.scope,
                EMPTY_ROWS,
                record.served.token,
            )
        }
        if (plan.membershipSettlements.length) return true
        for (const node of plan.membershipInstalls) {
            if (node.membershipChangedFromBefore) return true
        }
        return ownershipChanged
    }

    const rewireCommit = (planValue: CollectionCommitPlan): void => {
        const plan = planValue as ScopedCollectionCommitPlan
        for (const rowPlan of plan.rows) {
            if (!rowPlan.ownershipChanged) continue
            const { row, scope } = rowPlan.coordinate
            const record = scopeSidecars.get(scope)?.rowViews?.get(row)
            if (record === undefined) continue
            if (rowPlan.local.kind !== "none" || scope.parent === undefined) {
                detachRowView(record)
            } else {
                attachRowView(record, materializeRowView(scope.parent, row))
            }
        }
        for (const node of plan.membershipInstalls) {
            const record = node.installed
            const parent = node.parent?.existing ?? node.parent?.installed
            if (record !== undefined && parent !== undefined) {
                attachMembership(record, parent)
            }
        }
        if (plan.historyMarks !== undefined)
            for (const { scope, collection, history } of plan.historyMarks) {
                const record = scopeSidecars
                    .get(scope)
                    ?.memberships?.get(collection)
                if (record !== undefined) record.localHistory = history
            }
    }

    const settleCommit = (
        planValue: CollectionCommitPlan,
    ): readonly CollectionCommitSource[] | undefined => {
        const plan = planValue as ScopedCollectionCommitPlan
        for (const settlement of plan.rowSettlements) {
            const { record, outcome } = settlement
            record.served = Object.freeze({
                token: record.scope.createOutcomeToken(),
                outcome: servedOutcome(outcome),
            })
            recordCounter(record.scope, COLLECTION_ROW_SOURCES_CHANGED)
            recordDetail(
                record.scope,
                COLLECTION_ROW_PUBLISHED,
                record.atom,
                bindings.lookupRow(record.atom),
            )
            record.scope.coordinator.reachSubscriptionTarget(
                record.scope,
                record.atom as AnyState,
            )
        }
        for (const settlement of plan.membershipSettlements) {
            const { record, rows } = settlement
            record.served = servedMembership(
                record.scope,
                record.ordered === undefined
                    ? rows
                    : record.served.outcome.kind === "value"
                      ? (record.served.outcome.value as readonly object[])
                      : EMPTY_ROWS,
            )
            recordCounter(record.scope, COLLECTION_MEMBERSHIP_SOURCES_CHANGED)
            recordDetail(
                record.scope,
                COLLECTION_MEMBERSHIP_PUBLISHED,
                record.atom,
            )
            record.scope.coordinator.reachSubscriptionTarget(
                record.scope,
                record.atom as AnyState,
            )
        }
        const indexSources = plan.indexPlan?.publish()
        if (indexSources?.length) return [...plan.sources, ...indexSources]
        return plan.sources.length ? plan.sources : undefined
    }

    const commitPlan = function (
        this: ScopedCollectionCommitPlan,
        phase: 0 | 1 | 2,
    ) {
        if (phase === 0) return applyCommit(this)
        if (phase === 1) return rewireCommit(this)
        return settleCommit(this)
    } as CollectionCommitPlan["commit"]

    const disposeScope = (scopeValue: object): void => {
        const scope = scopeValue as StoreScopeNode
        indexes?.dispose(scope)
        const sidecar = scopeSidecars.get(scope)
        if (sidecar === undefined) return
        sidecar.liveRowViews?.forEach(record => {
            detachRowView(record)
            record.inheritingChildren.clear()
        })
        sidecar.liveMemberships?.forEach(record => {
            detachMembership(record)
            record.inheritingChildren.clear()
            record.indexedChildren?.clear()
            record.ordered?.entries.clear()
            record.ordered = undefined
            record.snapshotDirty = false
            record.served = servedMembership(
                record.scope,
                EMPTY_ROWS,
                record.served.token,
            )
        })
        sidecar.liveRowViews?.clear()
        sidecar.liveMemberships?.clear()
        const ownedRowCount = sidecar.ownedRows?.size ?? 0
        if (ownedRowCount !== 0) {
            recordCounter(scope, COLLECTION_OWNER_RELEASES, ownedRowCount)
        }
        sidecar.ownedRows?.clear()
        sidecar.rowLocals = undefined
        sidecar.ownedRows = undefined
        sidecar.rowViews = undefined
        sidecar.liveRowViews = undefined
        sidecar.memberships = undefined
        sidecar.liveMemberships = undefined
        scopeSidecars.delete(scope)
    }

    const kernel: CollectionDraftKernel = Object.freeze({
        installIndexes: (
            create: (host: CollectionIndexHost) => CollectionIndexRuntime,
        ) =>
            indexes ??
            (indexes = create({
                revision: (draft, collection) => {
                    const lane = laneFor(draft)
                    const revisions = (lane.queryRevisionByCollection ??=
                        new Map())
                    const revision = revisions.get(collection) ?? 0
                    revisions.set(collection, revision)
                    return revision
                },
                membership: indexedMembership,
                value: (scope, row) => {
                    const outcome = committedOutcome(scope, row)
                    return outcome.kind === "present"
                        ? outcome.value
                        : undefined
                },
                draftRows: readDraftCollection,
                draftValue: (draft, scope, row) => {
                    const lane = laneFor(draft)
                    let current: StoreScopeNode | undefined = scope
                    while (current !== undefined) {
                        const coordinate = lane.byScope.get(current)?.get(row)
                        const local =
                            coordinate === undefined
                                ? committedLocal(current, row)
                                : currentLocal(coordinate)
                        if (local.kind === "present") return local.value
                        if (local.kind === "absent") return undefined
                        current = current.parent
                    }
                    return undefined
                },
            })),
        has: (node: AnyState): boolean =>
            indexes?.has(node) === true ||
            bindings.lookupRow(node) !== undefined ||
            bindings.lookupCollection(node),
        diagnosticName: bindings.lookupDiagnosticName,
        read: (
            draftValue: object,
            scopeValue: object,
            node: AnyState,
        ): SynchronousResult => {
            const draft = draftValue as TreeDraft
            const scope = scopeValue as StoreScopeNode
            if (indexes?.has(node))
                return {
                    kind: "value",
                    value: indexes.read(draft, scope, node),
                }
            if (bindings.lookupRow(node) !== undefined) {
                return Object.freeze({
                    kind: "value",
                    value: readDraftRow(draft, scope, node),
                })
            }
            if (bindings.lookupCollection(node)) {
                return Object.freeze({
                    kind: "value",
                    value: readDraftCollection(draft, scope, node),
                })
            }
            throw new TypeError("Unknown collection scratch source")
        },
        stage: (
            draftValue: object,
            scopeValue: object,
            operation: CollectionMutationKind,
            row: AnyState,
            input: unknown,
            session: ControlFaultSession,
        ): void => {
            const draft = draftValue as TreeDraft
            const scope = scopeValue as StoreScopeNode
            if (operation === "set") {
                stageSet(draft, scope, row, input, session)
            } else if (operation === "update") {
                stageUpdate(draft, scope, row, input, session)
            } else if (operation === "delete") {
                stageDelete(draft, scope, row)
            } else {
                stageReset(draft, scope, row)
            }
        },
        scope: (
            scopeValue: object,
            node?: AnyState,
            session?: ControlFaultSession,
        ) => {
            if (node === undefined) {
                disposeScope(scopeValue)
                return undefined
            }
            if (indexes?.has(node))
                return indexes.scope(
                    scopeValue as StoreScopeNode,
                    node,
                    session,
                )
            if (bindings.lookupRow(node) !== undefined) {
                return materializeRowView(scopeValue as StoreScopeNode, node)
                    .served
            }
            if (!bindings.lookupCollection(node)) return undefined
            const record = materializeMembership(
                scopeValue as StoreScopeNode,
                node,
            )
            membershipRows(record)
            return record.served
        },
        plan: planCommit,
        resetAll: (draftValue: object, scopeValue: object): void =>
            resetAllRows(
                draftValue as TreeDraft,
                scopeValue as StoreScopeNode,
            ),
        stageSet,
        stageUpdate,
        stageDelete,
        stageReset,
        readDraftRow,
        readDraftCollection,
        beginMembershipRebuildTraceForTest: () => {
            if (membershipRebuildTraceForTest !== undefined) {
                throw new Error("A membership rebuild trace is already active")
            }
            let trace: object[] | undefined = []
            membershipRebuildTraceForTest = trace
            return () => {
                if (trace === undefined) {
                    throw new Error(
                        "The membership rebuild trace is already finished",
                    )
                }
                membershipRebuildTraceForTest = undefined
                const result = Object.freeze([...trace])
                trace.length = 0
                trace = undefined
                return result
            }
        },
        beginMembershipPlacementTraceForTest: () => {
            if (membershipPlacementTraceForTest !== undefined) {
                throw new Error(
                    "A membership placement trace is already active",
                )
            }
            let trace: { coordinates: number; states: number } | undefined = {
                coordinates: 0,
                states: 0,
            }
            membershipPlacementTraceForTest = trace
            return () => {
                if (trace === undefined) {
                    throw new Error(
                        "The membership placement trace is already finished",
                    )
                }
                membershipPlacementTraceForTest = undefined
                const result = Object.freeze({ ...trace })
                trace = undefined
                return result
            }
        },
        inspectDraft,
    })
    return kernel
}
